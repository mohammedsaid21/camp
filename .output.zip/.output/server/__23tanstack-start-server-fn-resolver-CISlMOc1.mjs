//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-CISlMOc1.js
var manifest = {
	"391315b0bde56e9440e63747a26659562f448fe0fe517b9eaf315647f658ee8c": {
		functionName: "lockVault_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	},
	"5c90e08da61efe51829d3c1e6dbc558bcf05248289264eca249251c865b19e93": {
		functionName: "prepareVaultUpload_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	},
	"66ef9086538fa452ca614e7e770a4790ea25c6a1ba23bae87e31318f26d4abe6": {
		functionName: "updateVaultVideoProject_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	},
	"6999eff64efc074641b86c94263049d976909a5d38d5ee0a0359ff24fe5c6ac1": {
		functionName: "finalizeVaultUpload_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	},
	"957618454c566f4cf78f719514b38ea8b5029ca6b07daf9135323b1f0175d74b": {
		functionName: "getVaultState_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	},
	"a6793d35fec75f4f895d82793fb0d268b8903d55e9431e56663044bc0dfdb512": {
		functionName: "unlockVault_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	},
	"e65ee69ec6a6bb599b1a51f854cdb66be811087ab732fcdd16cb3e976955fe9f": {
		functionName: "getPublicVideos_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	},
	"f6df6de2fd65654fa99316d95791c6a88451aadc5cc53bb39522a672fb6ccd39": {
		functionName: "deleteVaultVideo_createServerFn_handler",
		importer: () => import("./_ssr/vault.functions-BcKSaLPO.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
