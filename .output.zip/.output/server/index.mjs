globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { c as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-05T20:09:54.703Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/athar/clinic.jpg": {
		"type": "image/jpeg",
		"etag": "\"123d7-NxzS3LEnyVQV3TeMEelVmhyBoSc\"",
		"mtime": "2026-09-05T20:09:54.698Z",
		"size": 74711,
		"path": "../public/athar/clinic.jpg"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-05T20:09:54.704Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/athar/crates.jpg": {
		"type": "image/jpeg",
		"etag": "\"e8ea-bjUampg6p6N0I8RFurCVvXYG8iQ\"",
		"mtime": "2026-09-05T20:09:54.698Z",
		"size": 59626,
		"path": "../public/athar/crates.jpg"
	},
	"/athar/hands.jpg": {
		"type": "image/jpeg",
		"etag": "\"c711-AgrvR87ZHv6RLBGgXhVQk4TjSTc\"",
		"mtime": "2026-09-05T20:09:54.698Z",
		"size": 50961,
		"path": "../public/athar/hands.jpg"
	},
	"/athar/food.jpg": {
		"type": "image/jpeg",
		"etag": "\"1df2c-knjZhqNooj6BNvlPoArXgsCNDpI\"",
		"mtime": "2026-09-05T20:09:54.703Z",
		"size": 122668,
		"path": "../public/athar/food.jpg"
	},
	"/athar/hero.jpg": {
		"type": "image/jpeg",
		"etag": "\"2b302-Vzh+1hcC7ofXQzcxfnk5UyrhdNs\"",
		"mtime": "2026-09-05T20:09:54.699Z",
		"size": 176898,
		"path": "../public/athar/hero.jpg"
	},
	"/athar/medical.jpg": {
		"type": "image/jpeg",
		"etag": "\"23c38-7+GmcqVrRS8J6BrKtXMGjivFyg4\"",
		"mtime": "2026-09-05T20:09:54.701Z",
		"size": 146488,
		"path": "../public/athar/medical.jpg"
	},
	"/athar/water.jpg": {
		"type": "image/jpeg",
		"etag": "\"15d1c-4wgKIdO+usA9/XO0AvGomaF2Ubw\"",
		"mtime": "2026-09-05T20:09:54.703Z",
		"size": 89372,
		"path": "../public/athar/water.jpg"
	},
	"/assets/FundingMeter-_gtFHyze.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7f7-MrcxasQzVpIcl/aZnfTT+VK2lIk\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 2039,
		"path": "../public/assets/FundingMeter-_gtFHyze.js"
	},
	"/assets/Footer-jqTKEqIs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f7b-jegXM0nwPobzA/jDXPBvHklGX1M\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 8059,
		"path": "../public/assets/Footer-jqTKEqIs.js"
	},
	"/assets/Money-CxhLdLDA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"292-prAGqukXmE+qVw3VVqNlvXK29eI\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 658,
		"path": "../public/assets/Money-CxhLdLDA.js"
	},
	"/assets/PathSteps-CqMDhKmD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e9-Qtm7bIGgUGLMVQnqKPkQPxYvQSY\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 1769,
		"path": "../public/assets/PathSteps-CqMDhKmD.js"
	},
	"/assets/StickyMobileCTA-CF7BvM-m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"349-GjmfBp7n+bsiJPkXuJvOL1tul3Y\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 841,
		"path": "../public/assets/StickyMobileCTA-CF7BvM-m.js"
	},
	"/assets/VaultClipPlayer-5xu1yr43.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66f-qpluRQS+U0J6f5AJYzg5hbIS+BA\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 1647,
		"path": "../public/assets/VaultClipPlayer-5xu1yr43.js"
	},
	"/assets/_slug-CpufaaoS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1986-t3FJwV6Bwpdt9y51N1zRQnqF7Cs\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 6534,
		"path": "../public/assets/_slug-CpufaaoS.js"
	},
	"/assets/ayla-C5loukYM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"273f-VXhM3W1Sv/og1/S+EifQn/uhrSU\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 10047,
		"path": "../public/assets/ayla-C5loukYM.js"
	},
	"/assets/compressVideo-DKmaAJYL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1654-YGR6ojmakIbyP5pcKUHD52CDdSw\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 5716,
		"path": "../public/assets/compressVideo-DKmaAJYL.js"
	},
	"/assets/dist-Bq9C1jpM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c80-X9248w4A7UtoAFYilo4LqdH+LEw\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 7296,
		"path": "../public/assets/dist-Bq9C1jpM.js"
	},
	"/assets/impact-D8t2GUlo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4bc8-GxEo4Ex9nqNmyFDhdFm4Z7WZl0Q\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 19400,
		"path": "../public/assets/impact-D8t2GUlo.js"
	},
	"/assets/jsx-runtime-Cltr0gcK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20ee-ObwGPj96dlkL76iVLbX2wLAXzuw\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 8430,
		"path": "../public/assets/jsx-runtime-Cltr0gcK.js"
	},
	"/assets/motion-CuUA0Pmr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b1-N6vfFhhEYzgzEHg8VfqRX0jOPZU\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 433,
		"path": "../public/assets/motion-CuUA0Pmr.js"
	},
	"/athar/packs.jpg": {
		"type": "image/jpeg",
		"etag": "\"33256-FUqAPAfAucUJ3JJ+ghXBxTBGLPM\"",
		"mtime": "2026-09-05T20:09:54.703Z",
		"size": 209494,
		"path": "../public/athar/packs.jpg"
	},
	"/athar/غزة.jpeg": {
		"type": "image/jpeg",
		"etag": "\"22e39-KvxdQb0iebxMc7v5bND+wn/owlw\"",
		"mtime": "2026-09-05T20:09:54.701Z",
		"size": 142905,
		"path": "../public/athar/غزة.jpeg"
	},
	"/assets/index-B2iPt1ZH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b8a9-/5Jbd1y6aFX/jYOt5KTyNBmO3rg\"",
		"mtime": "2026-09-05T20:09:54.359Z",
		"size": 506025,
		"path": "../public/assets/index-B2iPt1ZH.js"
	},
	"/assets/not-found-i5RsCZif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-Trmr7GZIBZuvfg4uM18tBiRtOXg\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 118,
		"path": "../public/assets/not-found-i5RsCZif.js"
	},
	"/assets/projects-c98RZLEd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"257-/Myy+hdddefl/60rNHIXE5f/hnY\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 599,
		"path": "../public/assets/projects-c98RZLEd.js"
	},
	"/assets/route-BKvgxEZ-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-gZrnxgbHrZqXJzwsogR7d5V3HoE\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 155,
		"path": "../public/assets/route-BKvgxEZ-.js"
	},
	"/assets/route-CumR3m09.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a0-jhje0Zi/AyuIntQ7Pc4FmpnBlAU\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 416,
		"path": "../public/assets/route-CumR3m09.js"
	},
	"/assets/routes-BS7kqpTZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8794-lY1R3P1f/gD1YNp9JIBO9nfkpJ8\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 34708,
		"path": "../public/assets/routes-BS7kqpTZ.js"
	},
	"/assets/styles-vPqByxlY.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"171ae-oxL5DHApc1H4+yRdAwVkAKn0iNc\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 94638,
		"path": "../public/assets/styles-vPqByxlY.css"
	},
	"/assets/thanks-CZa8IM6U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"760-IAq9DtEqs1An4q5u+9A1MpU7eqs\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 1888,
		"path": "../public/assets/thanks-CZa8IM6U.js"
	},
	"/assets/useStore-CmhnSiq1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d4c-P3Y/y/hCbHZ/2vfnzoUfhWauHVY\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 19788,
		"path": "../public/assets/useStore-CmhnSiq1.js"
	},
	"/assets/videos-AkdIsB4A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1031-wvFe36eIrtCz6z5+3vOVwkB08Ys\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 4145,
		"path": "../public/assets/videos-AkdIsB4A.js"
	},
	"/assets/zakat-B7J7Yyut.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12fdc-p2y/+SZlYugM1vCi6flxfA6vivg\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 77788,
		"path": "../public/assets/zakat-B7J7Yyut.js"
	},
	"/assets/worker-BzdDEeh7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99a-D8cA1TaTqQUWUegjbCu49hzG/0w\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 2458,
		"path": "../public/assets/worker-BzdDEeh7.js"
	},
	"/athar/videos/bard.jpg": {
		"type": "image/jpeg",
		"etag": "\"7d8f-lw0TLsm3A9S9RLyjojokGXN5CR8\"",
		"mtime": "2026-09-05T20:09:54.698Z",
		"size": 32143,
		"path": "../public/athar/videos/bard.jpg"
	},
	"/athar/videos/khubz-2.jpg": {
		"type": "image/jpeg",
		"etag": "\"45ff-vK86FpHvdVnGzOWtyKlukQ71kxM\"",
		"mtime": "2026-09-05T20:09:54.703Z",
		"size": 17919,
		"path": "../public/athar/videos/khubz-2.jpg"
	},
	"/athar/videos/helw.jpg": {
		"type": "image/jpeg",
		"etag": "\"71d3-IHQO7mDBh5t45JwvB5n+XimfS78\"",
		"mtime": "2026-09-05T20:09:54.703Z",
		"size": 29139,
		"path": "../public/athar/videos/helw.jpg"
	},
	"/athar/videos/masjid.jpg": {
		"type": "image/jpeg",
		"etag": "\"2a68-4DtcIyFBOaF3UeurMoB6UIM5JiM\"",
		"mtime": "2026-09-05T20:09:54.704Z",
		"size": 10856,
		"path": "../public/athar/videos/masjid.jpg"
	},
	"/athar/videos/khubz.jpg": {
		"type": "image/jpeg",
		"etag": "\"539f-mCj4r+5jMzN/2OGl5fpzsJFsnIM\"",
		"mtime": "2026-09-05T20:09:54.703Z",
		"size": 21407,
		"path": "../public/athar/videos/khubz.jpg"
	},
	"/assets/utils-BYDHo02_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7ce6-ILWBe+8tP46PqfKzb/R5us1zjpY\"",
		"mtime": "2026-09-05T20:09:54.364Z",
		"size": 31974,
		"path": "../public/assets/utils-BYDHo02_.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_vH7rT5 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_vH7rT5
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
