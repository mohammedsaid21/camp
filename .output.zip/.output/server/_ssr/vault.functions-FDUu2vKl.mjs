import { a as VIDEO_PROJECT_IDS, t as VAULT_MAX_BYTES } from "./projects-D6nJ4DmA.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-CISlMOc1.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { i as stringType, n as numberType, r as objectType, t as enumType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vault.functions-FDUu2vKl.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getPublicVideos = createServerFn({ method: "GET" }).handler(createSsrRpc("e65ee69ec6a6bb599b1a51f854cdb66be811087ab732fcdd16cb3e976955fe9f"));
var getVaultState = createServerFn({ method: "GET" }).handler(createSsrRpc("957618454c566f4cf78f719514b38ea8b5029ca6b07daf9135323b1f0175d74b"));
var unlockVault = createServerFn({ method: "POST" }).validator(objectType({ password: stringType().min(1).max(80) })).handler(createSsrRpc("a6793d35fec75f4f895d82793fb0d268b8903d55e9431e56663044bc0dfdb512"));
var lockVault = createServerFn({ method: "POST" }).handler(createSsrRpc("391315b0bde56e9440e63747a26659562f448fe0fe517b9eaf315647f658ee8c"));
var prepareVaultUpload = createServerFn({ method: "POST" }).validator(objectType({
	title: stringType().trim().min(1).max(120),
	fileName: stringType().min(1).max(200),
	contentType: stringType().min(1).max(80),
	sizeBytes: numberType().int().positive().max(VAULT_MAX_BYTES)
})).handler(createSsrRpc("5c90e08da61efe51829d3c1e6dbc558bcf05248289264eca249251c865b19e93"));
var finalizeVaultUpload = createServerFn({ method: "POST" }).validator(objectType({
	path: stringType().min(1),
	title: stringType().trim().min(1).max(120),
	contentType: stringType().min(1).max(80),
	sizeBytes: numberType().int().positive().max(VAULT_MAX_BYTES),
	projectId: enumType(VIDEO_PROJECT_IDS)
})).handler(createSsrRpc("6999eff64efc074641b86c94263049d976909a5d38d5ee0a0359ff24fe5c6ac1"));
var updateVaultVideoProject = createServerFn({ method: "POST" }).validator(objectType({
	id: stringType().uuid(),
	projectId: enumType(VIDEO_PROJECT_IDS)
})).handler(createSsrRpc("66ef9086538fa452ca614e7e770a4790ea25c6a1ba23bae87e31318f26d4abe6"));
var deleteVaultVideo = createServerFn({ method: "POST" }).validator(objectType({ id: stringType().uuid() })).handler(createSsrRpc("f6df6de2fd65654fa99316d95791c6a88451aadc5cc53bb39522a672fb6ccd39"));
//#endregion
export { lockVault as a, updateVaultVideoProject as c, getVaultState as i, finalizeVaultUpload as n, prepareVaultUpload as o, getPublicVideos as r, unlockVault as s, deleteVaultVideo as t };
