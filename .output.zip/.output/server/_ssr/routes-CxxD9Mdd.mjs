import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as getPublicVideos } from "./vault.functions-FDUu2vKl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CxxD9Mdd.js
var $$splitComponentImporter = () => import("./routes-BbMQUdn5.mjs");
var Route = createFileRoute("/")({
	loader: () => getPublicVideos(),
	head: () => ({ meta: [
		{ title: "أثر — لكل تبرع أثر، ولكل أثر دليل" },
		{
			name: "description",
			content: "أثر بتوثّق شغلها بمخيم نسائم الرحمة: ربطات خبز لحوالي 80 عائلة، وإفطار لأكثر من 200 صائم."
		},
		{
			property: "og:title",
			content: "أثر — لكل تبرع أثر، ولكل أثر دليل"
		},
		{
			property: "og:description",
			content: "أرشيف توثيق للمشاريع الميدانية: الأرقام، الصور، والتقارير."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
