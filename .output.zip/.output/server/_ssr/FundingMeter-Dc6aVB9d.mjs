import { n as motion } from "../_libs/framer-motion+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Money } from "./Money-BeB2rs0p.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FundingMeter-Dc6aVB9d.js
var import_jsx_runtime = require_jsx_runtime();
/** نسبة الإنجاز من أرقام حقيقية فقط. لا تُخترع. */
function projectProgress(amountRaised, targetAmount) {
	if (amountRaised === null || targetAmount === null || targetAmount <= 0) return null;
	if (amountRaised < 0) return 0;
	return Math.min(amountRaised / targetAmount * 100, 100);
}
function remainingAmount(amountRaised, targetAmount) {
	if (amountRaised === null || targetAmount === null) return null;
	return Math.max(targetAmount - amountRaised, 0);
}
function isFunded(amountRaised, targetAmount, status) {
	if (status === "completed") return true;
	const progress = projectProgress(amountRaised, targetAmount);
	return progress !== null && progress >= 100;
}
function FundingMeter({ project, size = "card" }) {
	const progress = projectProgress(project.amountRaised, project.targetAmount);
	const remaining = remainingAmount(project.amountRaised, project.targetAmount);
	const funded = isFunded(project.amountRaised, project.targetAmount, project.status);
	if (progress === null || project.amountRaised === null || project.targetAmount === null) {
		if (funded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: size === "detail" ? "mt-6 text-base font-medium text-primary" : "text-sm font-medium text-primary",
			children: "اكتمل هذا الأثر"
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: size === "detail" ? "mt-6 text-sm text-muted-foreground" : "text-sm text-muted-foreground",
			children: "مساهمة مفتوحة — ما في عدّاد جمع منشور لهالمشروع بعد."
		});
	}
	const rounded = Math.round(progress);
	const barHeight = size === "detail" ? "h-2" : "h-1.5";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: size === "detail" ? "mt-6" : void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mb-1.5 flex justify-between ${size === "detail" ? "text-lg font-semibold" : "text-sm"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: project.amountRaised }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: project.targetAmount })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "progressbar",
				"aria-valuemin": 0,
				"aria-valuemax": 100,
				"aria-valuenow": rounded,
				"aria-label": "نسبة إنجاز المشروع",
				className: `overflow-hidden rounded-full bg-ivory ${barHeight}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					className: "h-full rounded-full bg-primary",
					initial: { width: 0 },
					animate: { width: `${progress}%` },
					transition: {
						duration: .55,
						ease: [
							.16,
							1,
							.3,
							1
						]
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1.5 text-sm text-muted-foreground",
				children: [
					funded ? "اكتمل المشروع" : remaining !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["المتبقي ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: remaining })] }) : null,
					size === "detail" ? ` · ${rounded}%` : null,
					project.donorCount !== null ? ` · ${project.donorCount} مساهمًا` : ""
				]
			})
		]
	});
}
//#endregion
export { isFunded as n, projectProgress as r, FundingMeter as t };
