//#region node_modules/.nitro/vite/services/ssr/assets/motion-eVtbxBLw.js
var fadeUp = {
	hidden: {
		opacity: 0,
		y: 56
	},
	visible: {
		opacity: 1,
		y: 0,
		transition: {
			duration: .85,
			ease: [
				.16,
				1,
				.3,
				1
			]
		}
	}
};
var imageReveal = {
	hidden: {
		clipPath: "inset(0 0 100% 0)",
		scale: 1.08,
		opacity: .4
	},
	visible: {
		clipPath: "inset(0 0 0% 0)",
		scale: 1,
		opacity: 1,
		transition: {
			duration: 1.15,
			ease: [
				.16,
				1,
				.3,
				1
			]
		}
	}
};
var stagger = (delay = .1) => ({
	hidden: {},
	visible: { transition: {
		staggerChildren: delay,
		delayChildren: .08
	} }
});
var viewport = {
	once: true,
	amount: .18,
	margin: "0px 0px -80px 0px"
};
//#endregion
export { viewport as i, imageReveal as n, stagger as r, fadeUp as t };
