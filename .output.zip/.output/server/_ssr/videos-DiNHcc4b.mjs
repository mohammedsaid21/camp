import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as getPublicVideos } from "./vault.functions-FDUu2vKl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/videos-DiNHcc4b.js
var $$splitComponentImporter = () => import("./videos-Cb667l1M.mjs");
var Route = createFileRoute("/videos")({
	head: () => ({ meta: [
		{ title: "الفيديوهات — أثر" },
		{
			name: "description",
			content: "كل فيديوهات التوثيق من مخيم نسائم الرحمة: توزيع الخبز، الحلو، البرد، ومناشدة المسجد."
		},
		{
			property: "og:title",
			content: "الفيديوهات — أثر"
		},
		{
			property: "og:description",
			content: "أرشيف فيديو من التنفيذ الميداني في مخيم نسائم الرحمة."
		}
	] }),
	loader: () => getPublicVideos(),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
