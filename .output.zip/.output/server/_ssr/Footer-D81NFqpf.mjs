import { n as __toESM } from "../_runtime.mjs";
import { n as motion, r as AnimatePresence } from "../_libs/framer-motion+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./Button-CnvJKd0u.mjs";
import { l as FOOTER_COLUMNS, p as NAV } from "./data-ZV2hr-of.mjs";
import { s as DonateButton } from "./DonateChoice-QCG4rJNl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Footer-D81NFqpf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Navbar() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("fixed inset-x-0 top-0 z-50 bg-forest text-forest-foreground transition-all duration-300", scrolled ? "py-3 shadow-[0_10px_30px_#0f3d2e40]" : "py-4"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "/",
					className: "font-display text-[1.75rem] leading-none tracking-tight text-white",
					children: ["أثر", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-accent",
						children: "."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-8 lg:flex",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "text-sm text-white/75 transition-colors hover:text-white",
						children: item.label
					}, item.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "/#archive",
							variant: "ghostOnDark",
							size: "sm",
							className: "hidden sm:inline-flex",
							children: "شوف التوثيق"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonateButton, {
							size: "sm",
							className: "hidden sm:inline-flex",
							children: "تبرع الآن"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-label": "القائمة",
							"aria-expanded": open,
							onClick: () => setOpen((v) => !v),
							className: "flex h-10 w-10 flex-col items-center justify-center gap-1.5 rounded-full border border-white/25 lg:hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-px w-4 bg-white transition-transform", open && "translate-y-[5px] rotate-45") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-px w-4 bg-white transition-opacity", open && "opacity-0") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-px w-4 bg-white transition-transform", open && "-translate-y-[5px] -rotate-45") })
							]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: {
				height: 0,
				opacity: 0
			},
			animate: {
				height: "auto",
				opacity: 1
			},
			exit: {
				height: 0,
				opacity: 0
			},
			transition: { duration: .25 },
			className: "overflow-hidden border-t border-white/15 bg-forest lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-col px-5 py-4",
				children: [NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					onClick: () => setOpen(false),
					className: "block border-b border-white/10 py-3.5 text-sm text-white/80",
					children: item.label
				}) }, item.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col gap-2 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						href: "/#archive",
						variant: "ghostOnDark",
						className: "w-full",
						children: "شوف التوثيق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonateButton, {
						className: "w-full",
						children: "تبرع الآن"
					})]
				})]
			})
		}) })]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border bg-background pt-8 pb-24 md:pb-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-8 border-b border-border pb-6 md:flex-row md:items-start md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-display text-2xl leading-none",
					children: ["أثر", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-accent",
						children: "."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-[34ch] text-sm text-muted-foreground",
					children: "منصّة بتوثّق شغلنا بمخيم نسائم الرحمة."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-10",
					children: FOOTER_COLUMNS.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "mb-2 text-sm font-semibold",
						children: col.h
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-1.5",
						children: col.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: item.href,
							className: "text-sm text-muted-foreground hover:text-primary",
							children: item.label
						}) }, item.label))
					})] }, col.h))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted-foreground",
				children: "نلتزم بحماية كرامة من نوثّق قصصهم. لا يُنشر اسم أو صورة دون موافقة."
			})]
		})
	});
}
//#endregion
export { Navbar as n, Footer as t };
