import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as getVaultState } from "./vault.functions-FDUu2vKl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ayla-B5fY0ZPr.js
var $$splitComponentImporter = () => import("./ayla-DuhcaWIX.mjs");
var Route = createFileRoute("/ayla")({
	head: () => ({ meta: [{ title: "خاص" }, {
		name: "robots",
		content: "noindex, nofollow"
	}] }),
	loader: () => getVaultState(),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
