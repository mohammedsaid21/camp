import { n as __toESM } from "../_runtime.mjs";
import { n as motion } from "../_libs/framer-motion+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./Button-CnvJKd0u.mjs";
import { n as loadImpactProjects } from "./catalog-CnAAOriP.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as isFunded, r as projectProgress, t as FundingMeter } from "./FundingMeter-Dc6aVB9d.mjs";
import { d as HADITH_UMMAH, f as HERO_IMAGE } from "./data-ZV2hr-of.mjs";
import { t as Route } from "./impact-DlOHKr4L.mjs";
import { i as viewport, r as stagger } from "./motion-eVtbxBLw.mjs";
import { n as VerseBand, t as PathSteps } from "./PathSteps-BJQALBky.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/impact-DDyo1xfI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var IMPACT_CATEGORIES = [
	{
		id: "all",
		label: "كل المشاريع"
	},
	{
		id: "orphans",
		label: "الأيتام"
	},
	{
		id: "families",
		label: "الأسر"
	},
	{
		id: "food",
		label: "الغذاء"
	},
	{
		id: "shelter",
		label: "المأوى"
	},
	{
		id: "income",
		label: "مصدر دخل"
	},
	{
		id: "education",
		label: "التعليم"
	},
	{
		id: "essentials",
		label: "الاحتياجات الأساسية"
	}
];
var IMPACT_INTENTS = [
	{
		id: "orphans",
		title: "كفالة يتيم",
		description: "ساعد في توفير احتياجات يتيم الأساسية والتعليمية والمعيشية."
	},
	{
		id: "shelter",
		title: "مأوى لعائلة",
		description: "ساهم في توفير خيمة أو مأوى وتجهيزات أساسية لعائلة فقدت منزلها."
	},
	{
		id: "food",
		title: "أطعم عائلة",
		description: "ساهم في توفير الغذاء والاحتياجات الأساسية لعائلة محتاجة."
	},
	{
		id: "income",
		title: "مصدر دخل لعائلة",
		description: "ساهم في إنشاء أو دعم مشروع صغير يساعد عائلة على بناء مصدر دخل مستدام."
	},
	{
		id: "education",
		title: "دعم تعليم طفل",
		description: "ساهم في توفير احتياجات تعليمية لطفل."
	},
	{
		id: "essentials",
		title: "مياه واحتياجات أساسية",
		description: "ساهم في توفير المياه والاحتياجات الأساسية للأسر المحتاجة."
	}
];
var cardEnter = {
	hidden: {
		opacity: 0,
		y: 16
	},
	visible: {
		opacity: 1,
		y: 0,
		transition: {
			duration: .4,
			ease: [
				.16,
				1,
				.3,
				1
			]
		}
	}
};
function ProjectCard({ project }) {
	const funded = isFunded(project.amountRaised, project.targetAmount, project.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.article, {
		variants: cardEnter,
		className: "group overflow-hidden rounded-3xl bg-card shadow-[0_8px_28px_#1435280c]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/impact/$slug",
			params: { slug: project.slug },
			className: "block rounded-3xl transition-transform duration-300 hover:-translate-y-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50 focus-visible:ring-offset-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-[16/10] overflow-hidden bg-ivory",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: project.image,
					alt: project.imageAlt,
					className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-3 start-3 rounded-full bg-background/92 px-3 py-1 text-xs font-medium backdrop-blur-sm",
					children: project.kicker
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-semibold",
							children: project.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted-foreground",
							children: project.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							children: project.place
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FundingMeter, { project }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex min-h-11 items-center text-sm font-semibold text-primary",
						children: funded ? "شوف هالأثر" : "ابدأ هذا الأثر"
					})
				]
			})]
		})
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
function sortProjects(projects, sort) {
	const copy = [...projects];
	if (sort === "closest") copy.sort((a, b) => {
		const pa = projectProgress(a.amountRaised, a.targetAmount);
		const pb = projectProgress(b.amountRaised, b.targetAmount);
		if (pa === null && pb === null) return 0;
		if (pa === null) return 1;
		if (pb === null) return -1;
		return pb - pa;
	});
	else if (sort === "supported") copy.sort((a, b) => (b.donorCount ?? -1) - (a.donorCount ?? -1));
	return copy;
}
function ImpactHome({ initialProjects }) {
	const [category, setCategory] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("newest");
	const query = useQuery({
		queryKey: ["impact-projects"],
		queryFn: loadImpactProjects,
		initialData: initialProjects,
		staleTime: Infinity
	});
	const visible = (0, import_react.useMemo)(() => {
		const list = query.data ?? [];
		return sortProjects(category === "all" ? list : list.filter((item) => item.category === category), sort);
	}, [
		category,
		query.data,
		sort
	]);
	const sorts = (0, import_react.useMemo)(() => {
		const list = query.data ?? [];
		const items = [{
			id: "newest",
			label: "الأحدث"
		}];
		if (list.some((item) => projectProgress(item.amountRaised, item.targetAmount) !== null)) items.push({
			id: "closest",
			label: "الأقرب للاكتمال"
		});
		if (list.some((item) => item.donorCount !== null)) items.push({
			id: "supported",
			label: "الأكثر دعمًا"
		});
		return items;
	}, [query.data]);
	function chooseCategory(next) {
		setCategory(next);
		document.getElementById("project-grid")?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-background pb-16 pt-24 md:pt-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-5 md:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-end gap-8 lg:grid-cols-[minmax(0,1.1fr)_0.9fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: "أثر تصنعه بإيدك"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 text-[clamp(2.2rem,8vw,4.2rem)] font-semibold leading-[1.1]",
							children: "اصنع أثرًا"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-[42ch] text-base leading-relaxed text-muted-foreground md:text-lg",
							children: "اختر أثرًا تريد أن تتركه، وساهم في تحويل تبرعك إلى شيء ملموس في حياة إنسان."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-col gap-2.5 sm:flex-row sm:flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								href: "#projects",
								arrow: false,
								className: "w-full sm:w-auto",
								children: "اختر مشروعك"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								href: "#how",
								variant: "ghost",
								className: "w-full sm:w-auto",
								arrow: false,
								children: "كيف يعمل؟"
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-3xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: HERO_IMAGE,
							alt: "توثيق ميداني من مخيم نسائم الرحمة",
							className: "aspect-[5/4] w-full object-cover sm:aspect-[16/10] lg:aspect-[5/4]"
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseBand, {
					ayah: HADITH_UMMAH.text,
					surah: HADITH_UMMAH.source
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "projects",
				className: "scroll-mt-28 mx-auto mt-12 max-w-7xl px-5 md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-semibold md:text-[1.85rem]",
						children: "ماذا تريد أن تصنع اليوم؟"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-[48ch] text-sm text-muted-foreground md:text-base",
						children: "اختر المشروع الأقرب إلى قلبك، وساهم بالمبلغ الذي تستطيع."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: "البطاقات أنواع أثر. المشاريع الظاهرة تحت هي اللي عندنا تنفيذ أو مساهمة مفتوحة إلها."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid grid-cols-2 gap-3 lg:grid-cols-3",
						children: IMPACT_INTENTS.map((intent) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => chooseCategory(intent.id),
							"aria-pressed": category === intent.id,
							className: cn("rounded-3xl bg-card p-4 text-start shadow-[0_8px_28px_#1435280c] transition-transform duration-300 hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50 md:p-5", category === intent.id && "ring-2 ring-primary/40"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-semibold md:text-lg",
								children: intent.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs leading-relaxed text-muted-foreground md:text-sm",
								children: intent.description
							})]
						}, intent.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex gap-2 overflow-x-auto pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
						role: "tablist",
						"aria-label": "تصفية المشاريع",
						children: IMPACT_CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": category === item.id,
							onClick: () => setCategory(item.id),
							className: cn("min-h-11 shrink-0 rounded-full px-4 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50", category === item.id ? "bg-forest text-forest-foreground" : "bg-ivory text-foreground"),
							children: item.label
						}, item.id))
					}),
					sorts.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "ترتيب"
						}), sorts.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSort(item.id),
							className: cn("min-h-11 rounded-full px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50", sort === item.id ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
							children: item.label
						}, item.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						id: "project-grid",
						className: "scroll-mt-28",
						children: [
							query.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 grid gap-6 sm:grid-cols-2",
								children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80 rounded-3xl" }, i))
							}),
							query.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 rounded-3xl bg-ivory p-8 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: "تعذر تحميل المشاريع."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void query.refetch(),
									className: "mt-4 min-h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50",
									children: "حاول مرة أخرى"
								})]
							}),
							query.isSuccess && visible.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 rounded-3xl bg-ivory p-8 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: "لا توجد مشاريع متاحة حاليًا."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: "نعمل على إضافة مشاريع جديدة قريبًا. ما منعرض مشاريع وهمية بهالتصنيف."
								})]
							}),
							query.isSuccess && visible.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								initial: "hidden",
								whileInView: "visible",
								viewport,
								variants: stagger(.08),
								className: "mt-8 grid gap-6 sm:grid-cols-2",
								children: visible.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectCard, { project }, project.id))
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "how",
				className: "scroll-mt-28 mx-auto mt-16 max-w-7xl px-5 md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-semibold",
						children: "كيف يعمل؟"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "بعد الرسالة، نفس المسار من المخيم للأرشيف."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 rounded-3xl bg-ivory px-5 py-6 md:px-8 md:py-7",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PathSteps, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto mt-16 max-w-7xl px-5 md:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl bg-forest px-5 py-8 text-forest-foreground md:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold",
							children: "تبرعك لا ينتهي عند الدفع."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-[46ch] text-sm leading-relaxed text-white/75",
							children: "نتابع المشاريع ونشارك تحديثاتها على الموقع لما يصير تنفيذ وتوثيق. ما منوعد ببريد تلقائي ما دام مش موجود بالنظام."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-6 grid gap-4 md:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-sm font-semibold",
									children: "وين يروح التبرع؟"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm text-white/70",
									children: "عبر واتساب للفريق، وبعدها تنفيذ بالمخيم حسب النوع المتفق عليه."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-sm font-semibold",
									children: "كيف نتابع؟"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm text-white/70",
									children: "تصوير من الأرض بعد التوزيع، والأرقام من العدّ الميداني."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-sm font-semibold",
									children: "كيف توصلك التحديثات؟"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm text-white/70",
									children: "بتظهر على صفحات التوثيق والفيديو بالموقع بعد التنفيذ."
								})] })
							]
						})
					]
				})
			})
		]
	});
}
function ImpactIndex() {
	const initialProjects = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImpactHome, { initialProjects });
}
//#endregion
export { ImpactIndex as component };
