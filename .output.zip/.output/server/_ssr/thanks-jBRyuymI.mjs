import { n as motion } from "../_libs/framer-motion+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { l as Heart } from "../_libs/lucide-react.mjs";
import { t as Button } from "./Button-CnvJKd0u.mjs";
import { t as Route } from "./route-DqACLSu3.mjs";
import { n as contributeMessage, r as parseContributeAmount, t as Money } from "./Money-BeB2rs0p.mjs";
import { g as originWhatsapp, i as DONATE_ORIGINS } from "./data-ZV2hr-of.mjs";
import { t as fadeUp } from "./motion-eVtbxBLw.mjs";
import { t as Route$1 } from "./thanks-DTCpPXCV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/thanks-jBRyuymI.js
var import_jsx_runtime = require_jsx_runtime();
function ImpactThanks({ project, amount }) {
	const message = contributeMessage(project.title, amount);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-background px-5 pb-20 pt-28 md:px-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: "hidden",
			animate: "visible",
			variants: fadeUp,
			className: "mx-auto max-w-lg rounded-3xl bg-card p-6 text-center shadow-[0_8px_28px_#1435280c] md:p-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
					className: "mx-auto h-8 w-8 fill-accent text-accent",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-[clamp(1.8rem,5vw,2.4rem)] font-semibold",
					children: "لقد صنعت أثرًا"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-base leading-relaxed text-muted-foreground",
					children: amount !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"اخترت تساهم بـ ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount }),
						" في مشروع ",
						project.title,
						"."
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"اخترت تساهم في مشروع ",
						project.title,
						"."
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-relaxed text-muted-foreground",
					children: "ما في دفع إلكتروني على الموقع. كمّل عبر واتساب، وبعد التنفيذ منشارك التحديثات هنا لما تتوفر."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex flex-col gap-2",
					children: DONATE_ORIGINS.map((origin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						href: originWhatsapp(origin.id, message),
						variant: origin.id === "outside" ? "donate" : "primary",
						className: "w-full",
						arrow: false,
						children: [origin.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium opacity-80",
							children: origin.code
						})]
					}, origin.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					href: "/impact",
					variant: "ghost",
					className: "mt-4 w-full",
					arrow: false,
					children: "اكتشف أثرًا آخر"
				})
			]
		})
	});
}
function ImpactThanksPage() {
	const { project } = Route.useLoaderData();
	const search = Route$1.useSearch();
	const amount = parseContributeAmount("amount" in search ? search.amount : void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImpactThanks, {
		project,
		amount
	});
}
//#endregion
export { ImpactThanksPage as component };
