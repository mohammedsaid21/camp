import { n as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as Info, f as Circle } from "../_libs/lucide-react.mjs";
import { t as Button } from "./Button-CnvJKd0u.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as DialogTrigger, r as DialogDescription, s as DonateButton, t as Dialog } from "./DonateChoice-QCG4rJNl.mjs";
import { n as Navbar, t as Footer } from "./Footer-D81NFqpf.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { n as RadioGroupIndicator, r as RadioGroupItem$1, t as RadioGroup$1 } from "../_libs/@radix-ui/react-radio-group+[...].mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/zakat-Cx0OVYL6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* قواعد حاسبة الزكاة — قابلة للمراجعة بدون تعديل الواجهة.
*
* الإصدار الأول يعتمد منهجًا واحدًا معلنًا للمستخدم.
* لا تُعرض أي قاعدة هنا على أنها إجماع إذا ورد فيها خلاف.
*/
var ZAKAT_RATE = .025;
/** ربع العشر = 1/40. المصدر: دار الإفتاء المصرية، فتوى نصاب زكاة المال. */
var ZAKAT_RATE_NUMERATOR = 1n;
var ZAKAT_RATE_DENOMINATOR = 40n;
var CURRENCIES = [
	"USD",
	"ILS",
	"JOD",
	"EUR",
	"GBP"
];
var CURRENCY_LABELS = {
	USD: "دولار أمريكي",
	ILS: "شيكل",
	JOD: "دينار أردني",
	EUR: "يورو",
	GBP: "جنيه إسترليني"
};
var ACTIVE_NISAB_METHOD = {
	/**
	* دار الإفتاء المصرية: نصاب المال = قيمة 85 جرامًا من الذهب عيار 21.
	* المصدر: https://www.dar-alifta.org/ar/fatwa/details/16827
	* الفتوى رقم 6203، 4 ديسمبر 1991م، فضيلة الدكتور محمد سيد طنطاوي.
	*/
	dar_alifta_gold_21k: {
		id: "dar_alifta_gold_21k",
		metal: "gold",
		grams: 85,
		karat: 21,
		labelAr: "نصاب الذهب عيار 21"
	},
	/**
	* مؤسسة الزكاة الأمريكية: نصاب النقد/الذهب = 85 جرامًا من الذهب الخالص (عيار 24)،
	* يعادل 20 دينارًا / نحو 3 أونصات أمريكية من الذهب الخالص.
	* المصدر: https://www.zakat.org/resource-center/conditions-and-calculations
	* هذا المنهج معرّف في المعمارية وغير مفعّل في الإصدار الأول.
	*/
	zfa_pure_gold: {
		id: "zfa_pure_gold",
		metal: "gold",
		grams: 85,
		karat: 24,
		labelAr: "نصاب الذهب الخالص"
	}
}["dar_alifta_gold_21k"];
var GOLD_KARATS = [
	24,
	22,
	21,
	18
];
/**
* خصم الديون:
* - دار الإفتاء: من شروط الوجوب أن يكون المال فارغًا من الدين، مع وجود خلاف مذهبي في التفصيل.
* - مؤسسة الزكاة الأمريكية: تُخصم الديون الضرورية الحالة فقط (إيجار، طعام، خدمات…)، لا الديون طويلة الأجل.
*   المصدر: https://www.zakat.org/resource-center/zakat-calculator
* الإصدار الأول يخصم فقط الديون الحالّة واجبة الأداء الفوري، ولا يخصم الأقساط المستقبلية تلقائيًا.
*/
var DEBT_DEDUCTION = {
	kind: "immediate_due_only",
	includeLongTerm: false
};
/**
* زكاة الأسهم — دار الإفتاء المصرية، فتوى 22181:
* https://dar-alifta.org/ar/fatwa/details/22181
* - أسهم للتجارة / التربص بالسعر: زكاة عروض تجارة على القيمة السوقية (+ الأرباح إن وُجدت).
* - أسهم غير تجارية (خدمية/إنتاجية/صناعية) بغير قصد التجارة: الزكاة في الربح فقط بعد النصاب والحول من يوم القبض.
* لا تُعامل كل الأسهم بنفس الحكم تلقائيًا.
*/
var STOCK_RULE = {
	tradeUsesMarketValue: true,
	longTermUsesReturnsOnly: true,
	unsureExcluded: true
};
/**
* الديون لك (الذمم):
* مؤسسة الزكاة الأمريكية تُدخل "القروض الجيدة المرجو سدادها" و"المستحقات المتوقعة" في الأصول.
* المصدر: حاسبة Zakat Foundation.
* الديون المشكوك في تحصيلها لا تُدخل تلقائيًا في الإصدار الأول.
*/
var RECEIVABLE_RULE = {
	includeExpectedRepayment: true,
	includeUncertain: false
};
var HAWL = {
	/** الحول المعتبر هنا حول هجري/قمري، لا سنة شمسية. المصدران المذكوران يتفقان على ذلك. */
	calendar: "hijri_lunar",
	/** لا تُحسب الزكاة واجبة إن لم يتحقق الحول. إذا كان المستخدم غير متأكد لا يُعرض رقم قطعي. */
	requireUserConfirmation: true
};
var SOURCES = [
	{
		id: "dar-nisab",
		title: "نصاب زكاة المال بالعملة المصرية — دار الإفتاء المصرية",
		href: "https://www.dar-alifta.org/ar/fatwa/details/16827/%D9%86%D8%B5%D8%A7%D8%A8-%D8%B2%D9%83%D8%A7%D8%A9-%D8%A7%D9%84%D9%85%D8%A7%D9%84-%D8%A8%D8%A7%D9%84%D8%B9%D9%85%D9%84%D8%A9-%D8%A7%D9%84%D9%85%D8%B5%D8%B1%D9%8A%D8%A9"
	},
	{
		id: "dar-savings",
		title: "زكاة المال في دفتر التوفير — دار الإفتاء المصرية",
		href: "https://dar-alifta.org/ar/fatwa/details/17620/%D8%A8%D9%8A%D8%A7%D9%86-%D9%83%D9%8A%D9%81%D9%8A%D8%A9-%D8%B2%D9%83%D8%A7%D8%A9-%D8%A7%D9%84%D9%85%D8%A7%D9%84-%D8%A7%D9%84%D9%85%D9%88%D8%AC%D9%88%D8%AF-%D9%81%D9%8A-%D8%AF%D9%81%D8%AA%D8%B1-%D8%A7%D9%84%D8%AA%D9%88%D9%81%D9%8A%D8%B1"
	},
	{
		id: "dar-stocks",
		title: "كيفية حساب الزكاة على المال المستثمر في الأسهم — دار الإفتاء المصرية",
		href: "https://dar-alifta.org/ar/fatwa/details/22181/%D9%83%D9%8A%D9%81%D9%8A%D8%A9-%D8%AD%D8%B3%D8%A7%D8%A8-%D8%A7%D9%84%D8%B2%D9%83%D8%A7%D8%A9-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D9%85%D8%A7%D9%84-%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D8%AB%D9%85%D8%B1-%D9%81%D9%8A-%D8%A7%D9%84%D8%A3%D8%B3%D9%87%D9%85"
	},
	{
		id: "zfa-calc",
		title: "Zakat Calculator — Zakat Foundation of America",
		href: "https://www.zakat.org/resource-center/zakat-calculator"
	},
	{
		id: "zfa-conditions",
		title: "Zakat Conditions & Calculations — Zakat Foundation of America",
		href: "https://www.zakat.org/resource-center/conditions-and-calculations"
	}
];
/**
* حساب مالي بكسور عشرية ثابتة (6 منازل) لتفادي أخطاء IEEE-754.
* التقريب للعرض فقط، وليس أثناء الجمع والضرب.
*/
var MONEY_SCALE = 1000000n;
var ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩";
var MoneyError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "MoneyError";
	}
};
function normalizeDigits(raw) {
	return raw.trim().replace(/[٠-٩]/g, (d) => String(ARABIC_DIGITS.indexOf(d))).replace(/,/g, "").replace(/٫/g, ".").replace(/\s/g, "");
}
/** يحوّل إدخال المستخدم إلى وحدات داخلية. يرفض السالب وغير الرقمي. */
function parseAmount(raw) {
	const text = normalizeDigits(raw);
	if (text === "" || text === ".") return 0n;
	if (text.startsWith("-")) throw new MoneyError("negative");
	if (!/^\d+(\.\d+)?$/.test(text)) throw new MoneyError("invalid");
	const [wholePart = "0", fracPart = ""] = text.split(".");
	const frac = (fracPart + "000000").slice(0, 6);
	const extra = fracPart.slice(6);
	if (/[^0-9]/.test(wholePart) || extra && /[^0]/.test(extra)) throw new MoneyError("invalid");
	return BigInt(wholePart === "" ? "0" : wholePart) * MONEY_SCALE + BigInt(frac);
}
function add(a, b) {
	return a + b;
}
function sum(values) {
	return values.reduce((acc, n) => acc + n, 0n);
}
function sub(a, b) {
	return a - b;
}
function max0(value) {
	return value < 0n ? 0n : value;
}
/** a * numerator / denominator مع تقريب إلى أقرب وحدة داخلية (نصف لأعلى). */
function mulDiv(amount, numerator, denominator) {
	if (denominator === 0n) throw new MoneyError("division_by_zero");
	return (amount * numerator + denominator / 2n) / denominator;
}
function goldValueFromWeight(params) {
	if (params.karat <= 0 || params.karat > 24) throw new MoneyError("invalid_karat");
	if (params.nisabKarat <= 0) throw new MoneyError("invalid_karat");
	return mulDiv(mulDiv(params.grams, BigInt(params.karat), BigInt(params.nisabKarat)), params.pricePerGramAtNisabKarat, MONEY_SCALE);
}
function formatAmount(amount, fractionDigits = 2) {
	const negative = amount < 0n;
	const abs = negative ? -amount : amount;
	const whole = abs / MONEY_SCALE;
	const fracText = (abs % MONEY_SCALE).toString().padStart(6, "0").slice(0, fractionDigits);
	const wholeText = whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	const sign = negative ? "-" : "";
	if (fractionDigits === 0) return `${sign}${wholeText}`;
	return `${sign}${wholeText}.${fracText}`;
}
function applyZakatRate(wealth) {
	return mulDiv(wealth, ZAKAT_RATE_NUMERATOR, ZAKAT_RATE_DENOMINATOR);
}
function calculateZakat(input) {
	const flags = [];
	const nisab = ACTIVE_NISAB_METHOD;
	const cash = sum([
		input.cashOnHand,
		input.bankBalances,
		input.otherCurrenciesConverted
	]);
	let gold = 0n;
	if (input.goldMode === "value") gold = input.goldValue;
	else if (input.goldGrams > 0n) if (input.goldKarat21PricePerGram === null) flags.push("gold_weight_needs_price");
	else gold = goldValueFromWeight({
		grams: input.goldGrams,
		karat: input.goldKarat,
		pricePerGramAtNisabKarat: input.goldKarat21PricePerGram,
		nisabKarat: nisab.karat
	});
	let silver = 0n;
	if (input.silverMode === "value") silver = input.silverValue;
	else if (input.silverGrams > 0n) if (input.silverPricePerGram === null) flags.push("silver_weight_needs_price");
	else silver = goldValueFromWeight({
		grams: input.silverGrams,
		karat: 24,
		pricePerGramAtNisabKarat: input.silverPricePerGram,
		nisabKarat: 24
	});
	let investments = 0n;
	if (input.stockPurpose === "trade") investments = add(input.stockMarketValue, input.stockReturns);
	else if (input.stockPurpose === "long_term") {
		investments = input.stockReturns;
		flags.push("stocks_returns_only");
	} else if (input.stockMarketValue > 0n || input.stockReturns > 0n) flags.push("stocks_unresolved");
	let receivables = 0n;
	if (input.receivableQuality === "expected" && RECEIVABLE_RULE.includeExpectedRepayment) receivables = input.receivables;
	else if (input.receivableQuality === "unsure" && input.receivables > 0n) flags.push("receivables_unresolved");
	const assetTotal = sum([
		cash,
		gold,
		silver,
		investments,
		receivables
	]);
	const liabilities = max0(input.immediateDebts);
	const zakatableWealth = max0(sub(assetTotal, liabilities));
	const nisabValue = input.goldKarat21PricePerGram === null ? null : goldValueFromWeight({
		grams: BigInt(nisab.grams) * MONEY_SCALE,
		karat: nisab.karat,
		pricePerGramAtNisabKarat: input.goldKarat21PricePerGram,
		nisabKarat: nisab.karat
	});
	const nisabReached = nisabValue === null ? null : zakatableWealth >= nisabValue;
	const computed = applyZakatRate(zakatableWealth);
	let obligation = "due";
	let zakatAmount = computed;
	let estimatedAmount = null;
	if (nisabValue === null) {
		obligation = "missing_gold_price";
		zakatAmount = null;
		flags.push("nisab_needs_gold_price");
	} else if (!nisabReached) {
		obligation = "below_nisab";
		zakatAmount = 0n;
	} else if (input.hawl === "no") {
		obligation = "hawl_not_met";
		zakatAmount = null;
	} else if (input.hawl === "unsure") {
		obligation = "hawl_unresolved";
		zakatAmount = null;
		estimatedAmount = computed;
	}
	if (STOCK_RULE.unsureExcluded && flags.includes("stocks_unresolved")) flags.push("result_excludes_unresolved_stocks");
	return {
		currency: input.currency,
		assets: {
			cash,
			gold,
			silver,
			investments,
			receivables,
			liabilities
		},
		assetTotal,
		liabilities,
		zakatableWealth,
		nisabGrams: nisab.grams,
		nisabKarat: nisab.karat,
		nisabValue,
		nisabReached,
		rate: ZAKAT_RATE,
		zakatAmount,
		estimatedAmount,
		obligation,
		flags
	};
}
var MARKET_PRICES = {
	goldKarat21PerGram: null,
	silverPerGram: null,
	currency: "USD",
	updatedAt: null,
	source: null,
	fxToBase: null
};
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var RadioGroup = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup$1, {
		className: cn("grid gap-2", className),
		...props,
		ref
	});
});
RadioGroup.displayName = RadioGroup$1.displayName;
var RadioGroupItem = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem$1, {
		ref,
		className: cn("aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupIndicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-3.5 w-3.5 fill-primary" })
		})
	});
});
RadioGroupItem.displayName = RadioGroupItem$1.displayName;
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-tooltip-content-transform-origin)", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var STEPS = [
	"أموالك",
	"الالتزامات",
	"النصاب والحول",
	"النتيجة"
];
var INITIAL = {
	currency: "USD",
	cashOnHand: "",
	bankBalances: "",
	otherCurrenciesConverted: "",
	goldKnowsValue: "no",
	goldValue: "",
	goldGrams: "",
	goldKarat: "21",
	silverKnowsValue: "no",
	silverValue: "",
	silverGrams: "",
	silverPrice: "",
	stockPurpose: "trade",
	stockMarketValue: "",
	stockReturns: "",
	receivableQuality: "expected",
	receivables: "",
	immediateDebts: "",
	hawl: "unsure",
	goldKarat21Price: MARKET_PRICES.goldKarat21PerGram ? String(MARKET_PRICES.goldKarat21PerGram) : ""
};
function readAmount(raw) {
	try {
		return parseAmount(raw);
	} catch (error) {
		if (error instanceof MoneyError) return 0n;
		throw error;
	}
}
function toInput(form) {
	const goldPriceRaw = form.goldKarat21Price.trim();
	let goldPrice = null;
	if (goldPriceRaw) try {
		goldPrice = parseAmount(goldPriceRaw);
	} catch {
		goldPrice = null;
	}
	const silverPriceRaw = form.silverPrice.trim();
	let silverPrice = null;
	if (silverPriceRaw) try {
		silverPrice = parseAmount(silverPriceRaw);
	} catch {
		silverPrice = null;
	}
	const karat = Number(form.goldKarat);
	return {
		currency: form.currency,
		cashOnHand: readAmount(form.cashOnHand),
		bankBalances: readAmount(form.bankBalances),
		otherCurrenciesConverted: readAmount(form.otherCurrenciesConverted),
		goldMode: form.goldKnowsValue === "yes" ? "value" : "weight",
		goldValue: readAmount(form.goldValue),
		goldGrams: readAmount(form.goldGrams),
		goldKarat: Number.isFinite(karat) && karat > 0 && karat <= 24 ? karat : 21,
		silverMode: form.silverKnowsValue === "yes" ? "value" : "weight",
		silverValue: readAmount(form.silverValue),
		silverGrams: readAmount(form.silverGrams),
		stockPurpose: form.stockPurpose,
		stockMarketValue: readAmount(form.stockMarketValue),
		stockReturns: readAmount(form.stockReturns),
		receivableQuality: form.receivableQuality,
		receivables: readAmount(form.receivables),
		immediateDebts: readAmount(form.immediateDebts),
		hawl: form.hawl,
		goldKarat21PricePerGram: goldPrice,
		silverPricePerGram: silverPrice
	};
}
function isPresetKarat(value) {
	return GOLD_KARATS.some((karat) => String(karat) === value);
}
function moneyField(id, label, value, onChange, hint) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: id,
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id,
				inputMode: "decimal",
				dir: "ltr",
				className: "h-11 rounded-xl text-start",
				value,
				onChange: (e) => onChange(e.target.value.replace(/[^\d.,٠-٩٫]/g, "")),
				"aria-describedby": hint ? `${id}-hint` : void 0
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: `${id}-hint`,
				className: "text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
function Choice({ legend, value, onChange, options, name }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
			className: "text-sm font-medium",
			children: legend
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
			name,
			value,
			onValueChange: (next) => onChange(next),
			className: "grid gap-2 sm:grid-cols-3",
			children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: cn("flex min-h-11 cursor-pointer items-center gap-2 rounded-xl border px-3 py-2 text-sm", value === option.value ? "border-primary bg-ivory" : "border-border bg-card"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, { value: option.value }), option.label]
			}, option.value))
		})]
	});
}
function InfoDialog({ trigger, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "inline-flex min-h-11 items-center gap-1 text-sm font-medium text-primary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
				className: "h-4 w-4",
				"aria-hidden": "true"
			}), trigger]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
		className: "max-w-lg rounded-3xl text-start",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
			className: "text-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2 text-sm leading-relaxed text-muted-foreground",
					children
				})
			})]
		})
	})] });
}
function ZakatCalculator() {
	const [step, setStep] = (0, import_react.useState)(0);
	const [form, setForm] = (0, import_react.useState)(INITIAL);
	const result = (0, import_react.useMemo)(() => calculateZakat(toInput(form)), [form]);
	const currency = form.currency;
	const money = (amount) => amount === null ? "—" : `${formatAmount(amount)} ${currency}`;
	const patch = (next) => setForm((current) => ({
		...current,
		...next
	}));
	const dueLabel = result.obligation === "due" ? money(result.zakatAmount) : result.obligation === "hawl_unresolved" ? "غير محسومة" : result.obligation === "hawl_not_met" || result.obligation === "below_nisab" ? money(0n) : "يلزم سعر الذهب";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, {
		delayDuration: 200,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-6 lg:grid-cols-[minmax(0,1.4fr)_20rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-card p-4 shadow-[0_12px_32px_#1435280f] md:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs font-medium text-muted-foreground",
								children: [
									"الخطوة ",
									step + 1,
									" من ",
									STEPS.length
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 h-1.5 overflow-hidden rounded-full bg-ivory",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-primary transition-all",
									style: { width: `${(step + 1) / STEPS.length * 100}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 text-xl font-semibold",
								children: STEPS[step]
							})
						]
					}),
					step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "currency",
										children: "عملة الحساب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "currency",
										className: "flex h-11 w-full rounded-xl border border-input bg-transparent px-3 text-sm",
										value: form.currency,
										onChange: (e) => patch({ currency: e.target.value }),
										children: CURRENCIES.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: code,
											children: [
												CURRENCY_LABELS[code],
												" (",
												code,
												")"
											]
										}, code))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "أدخل كل المبالغ بهذه العملة. التحويل التلقائي غير مفعّل لأنه لا يوجد سعر صرف محفوظ في الموقع."
									})
								]
							}),
							moneyField("gold-price", "سعر جرام الذهب عيار 21", form.goldKarat21Price, (goldKarat21Price) => patch({ goldKarat21Price }), MARKET_PRICES.updatedAt ? `آخر تحديث محفوظ: ${MARKET_PRICES.updatedAt}${MARKET_PRICES.source ? ` — ${MARKET_PRICES.source}` : ""}` : "لا يوجد سعر ذهب محفوظ في الموقع. أدخل السعر من مصدر موثوق عندك. الحاسبة لا تدّعي أن السعر مباشر."),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mb-3 text-sm font-semibold",
								children: "النقد والأرصدة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-2",
								children: [
									moneyField("cash", "النقد الموجود معك", form.cashOnHand, (cashOnHand) => patch({ cashOnHand })),
									moneyField("bank", "الأموال في الحسابات البنكية", form.bankBalances, (bankBalances) => patch({ bankBalances })),
									moneyField("fx", "عملات أخرى", form.otherCurrenciesConverted, (otherCurrenciesConverted) => patch({ otherCurrenciesConverted }), "أدخل قيمتها بعد تحويلها بنفسك إلى العملة المختارة.")
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-sm font-semibold",
										children: "الذهب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
										name: "gold-knows",
										legend: "هل تعرف قيمة الذهب؟",
										value: form.goldKnowsValue,
										onChange: (goldKnowsValue) => patch({ goldKnowsValue }),
										options: [{
											value: "yes",
											label: "نعم"
										}, {
											value: "no",
											label: "لا"
										}]
									}),
									form.goldKnowsValue === "yes" ? moneyField("gold-value", "قيمة الذهب", form.goldValue, (goldValue) => patch({ goldValue })) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-3 sm:grid-cols-2",
										children: [moneyField("gold-grams", "الوزن بالغرام", form.goldGrams, (goldGrams) => patch({ goldGrams })), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "gold-karat",
													children: "العيار"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													id: "gold-karat",
													className: "flex h-11 w-full rounded-xl border border-input bg-transparent px-3 text-sm",
													value: isPresetKarat(form.goldKarat) ? form.goldKarat : "other",
													onChange: (e) => {
														if (e.target.value === "other") patch({ goldKarat: "" });
														else patch({ goldKarat: e.target.value });
													},
													children: [GOLD_KARATS.map((karat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: String(karat),
														children: karat
													}, karat)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "other",
														children: "غير ذلك"
													})]
												}),
												!isPresetKarat(form.goldKarat) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													inputMode: "numeric",
													dir: "ltr",
													className: "h-11 rounded-xl text-start",
													placeholder: "عيار من 1 إلى 24",
													value: form.goldKarat,
													onChange: (e) => patch({ goldKarat: e.target.value }),
													"aria-label": "عيار الذهب المخصص"
												})
											]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-sm font-semibold",
										children: "الفضة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
										name: "silver-knows",
										legend: "هل تعرف قيمة الفضة؟",
										value: form.silverKnowsValue,
										onChange: (silverKnowsValue) => patch({ silverKnowsValue }),
										options: [{
											value: "yes",
											label: "نعم"
										}, {
											value: "no",
											label: "لا"
										}]
									}),
									form.silverKnowsValue === "yes" ? moneyField("silver-value", "قيمة الفضة", form.silverValue, (silverValue) => patch({ silverValue })) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-3 sm:grid-cols-2",
										children: [moneyField("silver-grams", "الوزن بالغرام", form.silverGrams, (silverGrams) => patch({ silverGrams })), moneyField("silver-price", "سعر جرام الفضة", form.silverPrice, (silverPrice) => patch({ silverPrice }), "يلزم إذا أدخلت الوزن لا القيمة.")]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-sm font-semibold",
											children: "الأسهم والاستثمارات"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
											asChild: true,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex min-h-11 items-center text-primary",
												"aria-label": "طريقة زكاة الأسهم",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-4 w-4" })
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
											className: "max-w-xs text-start leading-relaxed",
											children: "طريقة زكاة الأسهم تختلف بحسب الغرض من امتلاكها وطبيعة الاستثمار."
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
										name: "stocks",
										legend: "الغرض من الأسهم",
										value: form.stockPurpose,
										onChange: (stockPurpose) => patch({ stockPurpose }),
										options: [
											{
												value: "trade",
												label: "للتجارة"
											},
											{
												value: "long_term",
												label: "استثمار طويل"
											},
											{
												value: "unsure",
												label: "لست متأكدًا"
											}
										]
									}),
									moneyField("stock-value", "القيمة السوقية الحالية", form.stockMarketValue, (stockMarketValue) => patch({ stockMarketValue })),
									moneyField("stock-returns", "الأرباح أو العوائد", form.stockReturns, (stockReturns) => patch({ stockReturns }), form.stockPurpose === "long_term" ? "في منهج هذه الحاسبة، الاستثمار الطويل يُحسب من العوائد لا من أصل السهم." : "لا تُدخل الأرباح مرتين إذا كانت داخلة في القيمة السوقية.")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-sm font-semibold",
										children: "أموال مستحقة لك"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
										name: "recv",
										legend: "هل يُرجى سدادها؟",
										value: form.receivableQuality,
										onChange: (receivableQuality) => patch({ receivableQuality }),
										options: [{
											value: "expected",
											label: "مرجوة السداد"
										}, {
											value: "unsure",
											label: "غير متأكد"
										}]
									}),
									moneyField("recv-amount", "القروض والذمم والمستحقات", form.receivables, (receivables) => patch({ receivables }), "لا تُحسب تلقائيًا الديون المشكوك في تحصيلها.")
								]
							})
						]
					}),
					step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-muted-foreground",
								children: "أدخل فقط الديون التي تنطبق عليها شروط الخصم وفق طريقة الحساب المستخدمة."
							}),
							moneyField("debts", "ديون مستحقة عليك تدخل في الحساب", form.immediateDebts, (immediateDebts) => patch({ immediateDebts }), "الديون الحالّة واجبة الأداء الفوري. لا تُدخل أقساطًا مستقبلية طويلة الأجل."),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoDialog, {
								trigger: "ما الذي يمكن خصمه؟",
								title: "الديون التي تدخل في الخصم",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "هذه الحاسبة تخصم الديون الحالّة واجبة الأداء الآن، مثل إيجار أو فواتير أو التزامات فورية. هذا يوافق طريقة حاسبة مؤسسة الزكاة الأمريكية التي تستثني الديون طويلة الأجل." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "خصم كل الديون أو أقساط المستقبل كلها فيه خلاف فقهي. لذلك لا تخصم الحاسبة الرهون أو الأقساط المؤجلة تلقائيًا." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "إذا كانت ديونك كبيرة أو مختلطة، راجع جهة شرعية موثوقة." })
								]
							})
						]
					}),
					step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-ivory p-4 text-sm leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold text-foreground",
									children: "طريقة حساب النصاب المستخدمة في هذه الحاسبة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-muted-foreground",
									children: [
										"تعتمد هذه الحاسبة على نصاب الذهب وفق المنهج المحدد في إعدادات الحاسبة: ",
										ACTIVE_NISAB_METHOD.grams,
										" ",
										"جرامًا من الذهب عيار ",
										ACTIVE_NISAB_METHOD.karat,
										"."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoDialog, {
									trigger: "لماذا؟",
									title: "لماذا نصاب الذهب عيار 21؟",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "دار الإفتاء المصرية قدّرت نصاب زكاة المال بقيمة 85 جرامًا من الذهب عيار 21، ثم تُحسب الزكاة بنسبة 2.5% إذا حال الحول وكان المال فارغًا من الدين وفاضلًا عن الحاجة الأصلية." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "مؤسسة الزكاة الأمريكية تذكر 85 جرامًا من الذهب الخالص. هذا فرق معتبر، لذلك لم تُعرض القاعدة على أنها إجماع، والمنهج المفعّل هنا هو منهج دار الإفتاء فقط." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											className: "inline-block text-primary",
											href: SOURCES[0].href,
											target: "_blank",
											rel: "noreferrer",
											children: SOURCES[0].title
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-3 space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "النصاب" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
												ACTIVE_NISAB_METHOD.grams,
												" غ · عيار ",
												ACTIVE_NISAB_METHOD.karat
											] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "قيمة النصاب" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: money(result.nisabValue) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "حالة النصاب" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: result.nisabReached === null ? "يلزم سعر الذهب" : result.nisabReached ? "بلغ النصاب" : "لم يبلغ النصاب" })]
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							name: "hawl",
							legend: "هل بلغ مالك النصاب وحال عليه حول هجري كامل؟",
							value: form.hawl,
							onChange: (hawl) => patch({ hawl }),
							options: [
								{
									value: "yes",
									label: "نعم"
								},
								{
									value: "no",
									label: "لا"
								},
								{
									value: "unsure",
									label: "لست متأكدًا"
								}
							]
						})]
					}),
					step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							result.obligation === "hawl_not_met" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-2xl bg-ivory p-4 text-sm leading-relaxed",
								children: "بحسب طريقة الحساب المستخدمة، لا تظهر زكاة مال واجبة حاليًا ما لم تتحقق شروط الوجوب."
							}),
							result.obligation === "hawl_unresolved" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-2xl bg-ivory p-4 text-sm leading-relaxed",
								children: "مسألة الحول وبعض تفاصيل زكاة المال تختلف باختلاف الحالة والمنهج الفقهي. ننصح بمراجعة جهة شرعية موثوقة."
							}),
							result.obligation === "missing_gold_price" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-2xl bg-ivory p-4 text-sm leading-relaxed",
								children: "لا يمكن تحديد النصاب بدون سعر جرام الذهب عيار 21. ارجع للخطوة الأولى وأدخل السعر من مصدر تعتمده."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "space-y-2 rounded-2xl border border-border p-4 text-sm",
								children: [
									["إجمالي الأموال الداخلة في الحساب", money(result.assetTotal)],
									["الخصومات المؤهلة", money(result.liabilities)],
									["صافي الأموال الزكوية", money(result.zakatableWealth)],
									["النصاب", money(result.nisabValue)],
									["حالة النصاب", result.nisabReached === null ? "غير محسوب" : result.nisabReached ? "بلغ النصاب" : "لم يبلغ النصاب"],
									["نسبة الزكاة", "2.5%"]
								].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3 border-b border-border/70 py-1.5 last:border-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: k
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-medium",
										children: v
									})]
								}, k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-forest p-5 text-forest-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-white/70",
										children: result.obligation === "due" ? "الزكاة المستحقة" : "لا يُعرض مبلغ واجب قطعي"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-display text-3xl",
										children: result.obligation === "due" ? money(result.zakatAmount) : dueLabel
									}),
									result.obligation === "hawl_unresolved" && result.estimatedAmount !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-sm text-white/70",
										children: [
											"تقدير حسابي إن تحققت الشروط: ",
											money(result.estimatedAmount),
											" — ليس فتوى."
										]
									})
								]
							}),
							result.flags.includes("stocks_unresolved") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "أسهمك غير المصنّفة لم تدخل في المبلغ."
							}),
							result.flags.includes("receivables_unresolved") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "المستحقات غير المؤكدة لم تدخل في المبلغ."
							}),
							result.obligation === "due" && result.zakatAmount !== null && result.zakatAmount > 0n && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: "يمكنك إخراج زكاتك الآن"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonateButton, {
									className: "w-full sm:w-auto",
									message: `السلام عليكم، حابب أخرج زكاة مالي عبر أثر لمخيم نسائم الرحمة. المبلغ حسب الحاسبة: ${formatAmount(result.zakatAmount)} ${currency}.`,
									children: "أخرج زكاتك"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-2",
						children: [step > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "#zakat-calc",
							variant: "ghost",
							className: "min-w-28",
							arrow: false,
							onClick: () => setStep((s) => s - 1),
							children: "السابق"
						}), step < STEPS.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "#zakat-calc",
							className: "min-w-28",
							onClick: () => setStep((s) => s + 1),
							arrow: false,
							children: "متابعة"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden lg:sticky lg:top-28 lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-border bg-card p-5 shadow-[0_12px_32px_#1435280f]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: "ملخص الحساب"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: "صافي الزكوي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: money(result.zakatableWealth)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: "الزكاة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-semibold",
							children: dueLabel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs leading-relaxed text-muted-foreground",
							children: ["أسعار الذهب والعملات المستخدمة في الحساب آخر تحديث لها: ", MARKET_PRICES.updatedAt ?? "يُدخلها المستخدم، لا يوجد تحديث محفوظ."]
						})
					]
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 px-5 py-3 backdrop-blur-xl lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "الزكاة المستحقة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: dueLabel
				})] }), step < STEPS.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					href: "#zakat-calc",
					size: "sm",
					onClick: () => setStep((s) => s + 1),
					arrow: false,
					children: "متابعة"
				}) : result.obligation === "due" && result.zakatAmount !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonateButton, {
					size: "sm",
					message: `السلام عليكم، حابب أخرج زكاة مالي عبر أثر لمخيم نسائم الرحمة. المبلغ حسب الحاسبة: ${formatAmount(result.zakatAmount)} ${currency}.`,
					children: "أخرج زكاتك"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "راجِع النتيجة"
				})]
			})
		})]
	});
}
var METHOD_STEPS = [
	{
		n: "1",
		t: "تحديد مال الزكاة",
		d: "يشمل الذهب والفضة والأموال النقدية والأسهم المُعدَّة للتجارة، وكذلك عروض التجارة."
	},
	{
		n: "2",
		t: "التحقُّق من بلوغ النصاب",
		d: `هذه الحاسبة تقارن صافي مالك بنصاب الذهب المعتمد فيها: ${ACTIVE_NISAB_METHOD.grams} غرامًا عيار ${ACTIVE_NISAB_METHOD.karat}. يوجد منهج آخر يعتمد الفضة، وهو غير مفعّل هنا.`
	},
	{
		n: "3",
		t: "مرور الحَوْل",
		d: "الحول المعتبر سنة قمرية كاملة على المال بعد بلوغه النصاب. الحاسبة لا تفترض مرور الحول؛ تسألك."
	},
	{
		n: "4",
		t: "المقدار",
		d: "إذا وجبت الزكاة: 2.5% من صافي المال الزكوي، أو قسمة المبلغ على 40."
	},
	{
		n: "5",
		t: "خصم الديون المستحقة",
		d: "تُخصم الديون الحالّة واجبة الأداء الفوري قبل إخراج الزكاة، وفق المنهج المختار. لا تُخصم كل الالتزامات المستقبلية تلقائيًا."
	},
	{
		n: "6",
		t: "توجيه الزكاة لمستحقيها",
		d: null
	}
];
function ZakatMethod() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-12 space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-primary",
					children: "طريقة حساب الزكاة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl font-semibold",
					children: "من المال إلى المستحق، بست خطوات."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 grid gap-3 md:grid-cols-2",
					children: METHOD_STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-border bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm text-accent",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-semibold",
								children: step.t
							}),
							step.d ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted-foreground",
								children: step.d
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
								className: "font-verse mt-2 text-sm leading-loose md:text-base",
								children: ["﴿إِنَّمَا الصَّدَقَاتُ لِلْفُقَرَاءِ وَالْمَسَاكِينِ وَالْعَامِلِينَ عَلَيْهَا وَالْمُؤَلَّفَةِ قُلُوبُهُمْ وَفِي الرِّقَابِ وَالْغَارِمِينَ وَفِي سَبِيلِ اللَّهِ وَابْنِ السَّبِيلِ فَرِيضَةً مِنَ اللَّهِ وَاللَّهُ عَلِيمٌ حَكِيمٌ﴾", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
									className: "mt-1 font-sans text-xs text-muted-foreground",
									children: "سورة التوبة — ٦٠"
								})]
							})
						]
					}, step.n))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "methodology",
				className: "rounded-3xl border border-border bg-card p-5 md:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-semibold",
						children: "منهجية الحساب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 space-y-3 text-sm leading-relaxed",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-medium",
								children: "نسبة الزكاة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-muted-foreground",
								children: [ZAKAT_RATE * 100, "% (ربع العشر / قسمة 40). مصدر الوجوب بهذا المقدار: دار الإفتاء المصرية."]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-medium",
								children: "طريقة تحديد النصاب"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-muted-foreground",
								children: [
									"نصاب الذهب: ",
									ACTIVE_NISAB_METHOD.grams,
									" جرامًا عيار ",
									ACTIVE_NISAB_METHOD.karat,
									"، تُضرب في سعر الجرام الذي يدخله المستخدم. لا يوجد سعر ذهب وهمي في الموقع."
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-medium",
								children: "الحول"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-muted-foreground",
								children: [
									"حول قمري. الحاسبة تسأل ولا تفترض. إن كانت الإجابة «لا» لا يُعرض مبلغ واجب. إن كانت «لست متأكدًا» لا يُحسم الحكم. التقويم: ",
									HAWL.calendar,
									"."
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-medium",
								children: "الديون"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-muted-foreground",
								children: [
									"تُخصم الديون الحالّة فقط (",
									DEBT_DEDUCTION.kind,
									"). الديون طويلة الأجل لا تُخصم تلقائيًا."
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-medium",
								children: "الذهب"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-muted-foreground",
								children: [
									"إن أدخلت القيمة تُستخدم كما هي. إن أدخلت الوزن والعيار تُحسب القيمة نسبة إلى عيار النصاب وسعر الجرام عيار",
									" ",
									ACTIVE_NISAB_METHOD.karat,
									". حُليّ الزينة فيه خلاف، ولم تُستثنَ تلقائيًا."
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-medium",
								children: "الأسهم"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-muted-foreground",
								children: [
									"للتجارة: القيمة السوقية. للاستثمار الطويل: العوائد فقط وفق فتوى دار الإفتاء في الأسهم. إن لم تتأكد لا تُحسب. استبعاد غير المصنّف: ",
									STOCK_RULE.unsureExcluded ? "نعم" : "لا",
									"."
								]
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-6 font-semibold",
						children: "المصادر الشرعية"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1.5 text-sm",
						children: SOURCES.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: source.href,
							target: "_blank",
							rel: "noreferrer",
							className: "text-primary hover:underline",
							children: source.title
						}) }, source.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted-foreground",
				children: "هذه الحاسبة أداة مساعدة وليست فتوى شرعية. قد تختلف بعض تفاصيل حساب الزكاة باختلاف نوع المال والحالة الشخصية والمنهج الفقهي المتبع. إذا كانت حالتك معقدة، مثل الشركات أو الاستثمارات أو الديون الكبيرة، فاستشر جهة شرعية موثوقة."
			})
		]
	});
}
function ZakatPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "zakat-calc",
		className: "bg-surface pt-28 pb-28 md:pb-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-8 max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: "عبادة مالية، مش مجرد رقم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-[clamp(1.7rem,4vw,2.4rem)] font-semibold leading-snug",
							children: "احسب زكاتك"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground md:text-base",
							children: "أدخل أموالك، تُحسب قيمة النصاب من سعر الذهب الذي تعتمده، ويُسأل عن الحول، ثم تظهر النتيجة بالتفصيل. المنهج المستخدم معلن، والحاسبة لا تخترع سعرًا ولا فتوى."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZakatCalculator, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZakatMethod, {})
			]
		})
	});
}
function ZakatRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZakatPage, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { ZakatRoute as component };
