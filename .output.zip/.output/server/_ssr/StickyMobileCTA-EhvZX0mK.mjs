import { n as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as DonateButton } from "./DonateChoice-QCG4rJNl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StickyMobileCTA-EhvZX0mK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StickyMobileCTA() {
	const [visible, setVisible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setVisible(window.scrollY > 640);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 px-5 py-3 backdrop-blur-xl transition-transform duration-300 lg:hidden", visible ? "translate-y-0" : "translate-y-full"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "توثيق من المخيم"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonateButton, {
				size: "sm",
				children: "تبرع الآن"
			})]
		})
	});
}
//#endregion
export { StickyMobileCTA as t };
