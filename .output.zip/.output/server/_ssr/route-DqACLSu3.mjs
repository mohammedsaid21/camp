import { t as getImpactProject } from "./catalog-CnAAOriP.mjs";
import { M as notFound, f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-DqACLSu3.js
var $$splitComponentImporter = () => import("./route-BiBLxcXv.mjs");
var Route = createFileRoute("/impact/$slug")({
	loader: ({ params }) => {
		const project = getImpactProject(params.slug);
		if (!project) throw notFound();
		return { project };
	},
	head: ({ loaderData }) => {
		const project = loaderData?.project;
		const title = project ? `${project.title} | اصنع أثرًا | أثر` : "اصنع أثرًا | أثر";
		const description = project?.summary ?? "اختر مشروعًا وكن جزءًا من أثر حقيقي.";
		return { meta: [
			{ title },
			{
				name: "description",
				content: description
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: description
			}
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
