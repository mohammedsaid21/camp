import { a as VIDEO_PROJECT_IDS, n as VAULT_MIME_TYPES, s as isVideoProjectId, t as VAULT_MAX_BYTES } from "./projects-D6nJ4DmA.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { i as stringType, n as numberType, r as objectType, t as enumType } from "../_libs/zod.mjs";
import { i as getRequestProtocol$1, n as getCookie, r as getRequestIP$1, s as setCookie$1, t as deleteCookie$1 } from "./request-response-BlYHa3On.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import processModule from "node:process";
import { Buffer } from "node:buffer";
import { createHash, createHmac, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/vault.functions-BcKSaLPO.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function readEnv(name) {
	const value = processModule.env[name];
	return value && value.length > 0 ? value : void 0;
}
function supabaseUrl() {
	const url = readEnv("SUPABASE_URL") ?? readEnv("VITE_SUPABASE_URL") ?? readEnv("NEXT_PUBLIC_SUPABASE_URL");
	if (!url) throw new Error("Missing SUPABASE_URL");
	return url;
}
function supabaseServiceKey() {
	const key = readEnv("SUPABASE_SERVICE_ROLE_KEY");
	if (!key) throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY");
	return key;
}
function vaultPassword() {
	return readEnv("VAULT_PASSWORD") ?? "ayla21";
}
function vaultSessionSecret() {
	const secret = readEnv("VAULT_SESSION_SECRET");
	if (secret && secret.length >= 32) return secret;
	return createHash("sha256").update(`athar-vault:${vaultPassword()}`).digest("hex");
}
var COOKIE = "athar_vault";
function expectedToken() {
	return createHmac("sha256", vaultSessionSecret()).update("vault-unlocked").digest("hex");
}
function equal(left, right) {
	const a = Buffer.from(left);
	const b = Buffer.from(right);
	if (a.length !== b.length) {
		timingSafeEqual(a, a);
		return false;
	}
	return timingSafeEqual(a, b);
}
function vaultUnlocked() {
	const token = getCookie(COOKIE);
	return Boolean(token && equal(token, expectedToken()));
}
function passwordMatches(input) {
	return equal(input, vaultPassword());
}
function issueVaultCookie() {
	setCookie$1(COOKIE, expectedToken(), {
		httpOnly: true,
		sameSite: "lax",
		path: "/",
		maxAge: 604800,
		secure: getRequestProtocol$1() === "https"
	});
}
function clearVaultCookie() {
	deleteCookie$1(COOKIE, { path: "/" });
}
function requireVault() {
	if (!vaultUnlocked()) {
		const error = /* @__PURE__ */ new Error("Unauthorized");
		error.name = "VaultAuthError";
		throw error;
	}
}
var admin;
var VAULT_BUCKET = "vault-videos";
function supabaseAdmin() {
	admin ??= createClient(supabaseUrl(), supabaseServiceKey(), { auth: {
		persistSession: false,
		autoRefreshToken: false
	} });
	return admin;
}
var attempts = /* @__PURE__ */ new Map();
function clientKey() {
	return getRequestIP$1({ xForwardedFor: true }) ?? "local";
}
function allowUnlockAttempt() {
	const now = Date.now();
	const current = attempts.get(clientKey());
	if (!current || current.resetAt < now) {
		attempts.set(clientKey(), {
			count: 1,
			resetAt: now + 6e5
		});
		return true;
	}
	if (current.count >= 8) return false;
	current.count += 1;
	return true;
}
function extensionFor(fileName, mime) {
	const fromName = fileName.split(".").pop()?.toLowerCase();
	if (fromName && /^[a-z0-9]{2,5}$/.test(fromName)) return fromName;
	if (mime === "video/webm") return "webm";
	if (mime === "video/quicktime") return "mov";
	if (mime === "video/x-matroska") return "mkv";
	return "mp4";
}
async function signedDownload(path) {
	const { data, error } = await supabaseAdmin().storage.from(VAULT_BUCKET).createSignedUrl(path, 7200);
	if (error || !data?.signedUrl) throw new Error(error?.message ?? "تعذر تجهيز رابط المشاهدة");
	return data.signedUrl;
}
function asClip(row) {
	return Promise.all([signedDownload(row.storage_path), row.poster_path ? signedDownload(row.poster_path) : Promise.resolve(null)]).then(([videoUrl, posterUrl]) => ({
		id: row.id,
		title: row.title,
		videoUrl,
		posterUrl,
		createdAt: row.created_at,
		projectId: row.project_id && isVideoProjectId(row.project_id) ? row.project_id : "other"
	}));
}
async function listClips() {
	const { data, error } = await supabaseAdmin().from("vault_videos").select("id, title, storage_path, poster_path, created_at, project_id").order("created_at", { ascending: false });
	if (error) throw new Error(error.message);
	return Promise.all((data ?? []).map((row) => asClip({
		id: row.id,
		title: row.title,
		storage_path: row.storage_path,
		poster_path: row.poster_path ?? null,
		created_at: row.created_at,
		project_id: row.project_id ?? null
	})));
}
var getPublicVideos_createServerFn_handler = createServerRpc({
	id: "e65ee69ec6a6bb599b1a51f854cdb66be811087ab732fcdd16cb3e976955fe9f",
	name: "getPublicVideos",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => getPublicVideos.__executeServer(opts));
var getPublicVideos = createServerFn({ method: "GET" }).handler(getPublicVideos_createServerFn_handler, async () => {
	try {
		return await listClips();
	} catch (error) {
		console.error(error);
		return [];
	}
});
var getVaultState_createServerFn_handler = createServerRpc({
	id: "957618454c566f4cf78f719514b38ea8b5029ca6b07daf9135323b1f0175d74b",
	name: "getVaultState",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => getVaultState.__executeServer(opts));
var getVaultState = createServerFn({ method: "GET" }).handler(getVaultState_createServerFn_handler, async () => {
	if (!vaultUnlocked()) return {
		unlocked: false,
		videos: []
	};
	return {
		unlocked: true,
		videos: await listClips()
	};
});
var unlockVault_createServerFn_handler = createServerRpc({
	id: "a6793d35fec75f4f895d82793fb0d268b8903d55e9431e56663044bc0dfdb512",
	name: "unlockVault",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => unlockVault.__executeServer(opts));
var unlockVault = createServerFn({ method: "POST" }).validator(objectType({ password: stringType().min(1).max(80) })).handler(unlockVault_createServerFn_handler, async ({ data }) => {
	if (!allowUnlockAttempt()) throw new Error("محاولات كثيرة. انتظر شوي وجرب مرة ثانية.");
	if (!passwordMatches(data.password)) throw new Error("كلمة السر غلط.");
	issueVaultCookie();
	return {
		unlocked: true,
		videos: await listClips()
	};
});
var lockVault_createServerFn_handler = createServerRpc({
	id: "391315b0bde56e9440e63747a26659562f448fe0fe517b9eaf315647f658ee8c",
	name: "lockVault",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => lockVault.__executeServer(opts));
var lockVault = createServerFn({ method: "POST" }).handler(lockVault_createServerFn_handler, async () => {
	clearVaultCookie();
	return { unlocked: false };
});
var prepareVaultUpload_createServerFn_handler = createServerRpc({
	id: "5c90e08da61efe51829d3c1e6dbc558bcf05248289264eca249251c865b19e93",
	name: "prepareVaultUpload",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => prepareVaultUpload.__executeServer(opts));
var prepareVaultUpload = createServerFn({ method: "POST" }).validator(objectType({
	title: stringType().trim().min(1).max(120),
	fileName: stringType().min(1).max(200),
	contentType: stringType().min(1).max(80),
	sizeBytes: numberType().int().positive().max(VAULT_MAX_BYTES)
})).handler(prepareVaultUpload_createServerFn_handler, async ({ data }) => {
	requireVault();
	if (!VAULT_MIME_TYPES.includes(data.contentType)) throw new Error("صيغة الفيديو غير مدعومة. استخدم mp4 أو webm.");
	const path = `videos/${crypto.randomUUID()}.${extensionFor(data.fileName, data.contentType)}`;
	const { data: signed, error } = await supabaseAdmin().storage.from(VAULT_BUCKET).createSignedUploadUrl(path, { upsert: true });
	if (error || !signed) throw new Error(error?.message ?? "تعذر تجهيز الرفع");
	return {
		path,
		token: signed.token,
		signedUrl: signed.signedUrl,
		title: data.title,
		contentType: data.contentType,
		sizeBytes: data.sizeBytes
	};
});
var finalizeVaultUpload_createServerFn_handler = createServerRpc({
	id: "6999eff64efc074641b86c94263049d976909a5d38d5ee0a0359ff24fe5c6ac1",
	name: "finalizeVaultUpload",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => finalizeVaultUpload.__executeServer(opts));
var finalizeVaultUpload = createServerFn({ method: "POST" }).validator(objectType({
	path: stringType().min(1),
	title: stringType().trim().min(1).max(120),
	contentType: stringType().min(1).max(80),
	sizeBytes: numberType().int().positive().max(VAULT_MAX_BYTES),
	projectId: enumType(VIDEO_PROJECT_IDS)
})).handler(finalizeVaultUpload_createServerFn_handler, async ({ data }) => {
	requireVault();
	if (!data.path.startsWith("videos/")) throw new Error("مسار غير صالح");
	const { data: inserted, error } = await supabaseAdmin().from("vault_videos").insert({
		title: data.title,
		storage_path: data.path,
		mime_type: data.contentType,
		size_bytes: data.sizeBytes,
		project_id: data.projectId
	}).select("id, title, storage_path, poster_path, created_at, project_id").single();
	if (error || !inserted) throw new Error(error?.message ?? "تعذر حفظ الفيديو");
	return asClip({
		id: inserted.id,
		title: inserted.title,
		storage_path: inserted.storage_path,
		poster_path: inserted.poster_path ?? null,
		created_at: inserted.created_at,
		project_id: inserted.project_id ?? data.projectId
	});
});
var updateVaultVideoProject_createServerFn_handler = createServerRpc({
	id: "66ef9086538fa452ca614e7e770a4790ea25c6a1ba23bae87e31318f26d4abe6",
	name: "updateVaultVideoProject",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => updateVaultVideoProject.__executeServer(opts));
var updateVaultVideoProject = createServerFn({ method: "POST" }).validator(objectType({
	id: stringType().uuid(),
	projectId: enumType(VIDEO_PROJECT_IDS)
})).handler(updateVaultVideoProject_createServerFn_handler, async ({ data }) => {
	requireVault();
	const { error } = await supabaseAdmin().from("vault_videos").update({ project_id: data.projectId }).eq("id", data.id);
	if (error) throw new Error(error.message);
	return {
		id: data.id,
		projectId: data.projectId
	};
});
var deleteVaultVideo_createServerFn_handler = createServerRpc({
	id: "f6df6de2fd65654fa99316d95791c6a88451aadc5cc53bb39522a672fb6ccd39",
	name: "deleteVaultVideo",
	filename: "src/lib/vault/vault.functions.ts"
}, (opts) => deleteVaultVideo.__executeServer(opts));
var deleteVaultVideo = createServerFn({ method: "POST" }).validator(objectType({ id: stringType().uuid() })).handler(deleteVaultVideo_createServerFn_handler, async ({ data }) => {
	requireVault();
	const { data: row, error: readError } = await supabaseAdmin().from("vault_videos").select("storage_path, poster_path").eq("id", data.id).maybeSingle();
	if (readError) throw new Error(readError.message);
	if (!row) throw new Error("الفيديو مش موجود");
	const paths = [row.storage_path, row.poster_path].filter((path) => Boolean(path));
	if (paths.length > 0) {
		const { error: storageError } = await supabaseAdmin().storage.from(VAULT_BUCKET).remove(paths);
		if (storageError) throw new Error(storageError.message);
	}
	const { error } = await supabaseAdmin().from("vault_videos").delete().eq("id", data.id);
	if (error) throw new Error(error.message);
	return { id: data.id };
});
//#endregion
export { deleteVaultVideo_createServerFn_handler, finalizeVaultUpload_createServerFn_handler, getPublicVideos_createServerFn_handler, getVaultState_createServerFn_handler, lockVault_createServerFn_handler, prepareVaultUpload_createServerFn_handler, unlockVault_createServerFn_handler, updateVaultVideoProject_createServerFn_handler };
