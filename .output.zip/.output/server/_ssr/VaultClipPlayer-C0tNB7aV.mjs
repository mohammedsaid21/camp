import { n as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as Play } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/VaultClipPlayer-C0tNB7aV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VaultClipPlayer({ src, poster, title, className }) {
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (failed || !playing) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => {
			if (!failed) setPlaying(true);
		},
		className: cn("relative block aspect-[9/16] w-full overflow-hidden bg-charcoal", className),
		"aria-label": failed ? title : `تشغيل فيديو ${title}`,
		children: [
			poster ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: poster,
				alt: "",
				className: "h-full w-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full bg-forest" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-charcoal/25" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0 flex items-center justify-center",
				children: !failed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-14 w-14 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-[0_10px_24px_#f26b214d]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
						className: "ms-0.5 h-6 w-6 fill-current",
						"aria-hidden": "true"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-3 start-3 rounded-full border border-white/25 bg-background/92 px-2.5 py-1 text-[11px] font-medium backdrop-blur-sm",
				children: failed ? "تعذر التشغيل" : "مشاهدة الفيديو"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative aspect-[9/16] overflow-hidden bg-black", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			className: "field-clip-video h-full w-full object-contain",
			controls: true,
			playsInline: true,
			autoPlay: true,
			preload: "metadata",
			poster: poster ?? void 0,
			onError: () => {
				setFailed(true);
				setPlaying(false);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", { src })
		})
	});
}
//#endregion
export { VaultClipPlayer as t };
