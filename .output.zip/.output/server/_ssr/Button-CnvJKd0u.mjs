import { n as motion } from "../_libs/framer-motion+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { l as Heart, m as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Button-CnvJKd0u.js
var import_jsx_runtime = require_jsx_runtime();
function Button({ href, children, variant = "primary", className, size = "default", arrow = true, onClick }) {
	const base = "btn-shine inline-flex min-h-11 items-center justify-center gap-2 font-semibold transition-[transform,box-shadow,background] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50 focus-visible:ring-offset-2 focus-visible:ring-offset-background";
	const sizes = {
		default: "rounded-full px-7 py-3 text-sm",
		sm: "rounded-full px-5 py-2.5 text-sm"
	};
	const variants = {
		primary: "bg-primary text-primary-foreground shadow-[0_10px_24px_#1b7a4a44] hover:bg-[#166c41]",
		donate: "btn-donate bg-accent text-accent-foreground shadow-[0_10px_24px_#f26b214d] hover:bg-ember",
		ghost: "border-2 border-primary/30 bg-white text-primary hover:border-primary hover:bg-ivory",
		ghostOnDark: "border border-white/45 bg-white/10 text-white hover:border-white hover:bg-white/20",
		link: "rounded-none border-b-2 border-accent px-0 pb-0.5 text-accent shadow-none hover:border-ember"
	};
	const showHeart = variant === "donate";
	const showArrow = arrow && variant !== "link" && variant !== "donate";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.a, {
		href,
		onClick,
		target: href.startsWith("http") ? "_blank" : void 0,
		rel: href.startsWith("http") ? "noopener noreferrer" : void 0,
		whileHover: { y: variant === "link" ? 0 : -2 },
		whileTap: { scale: .98 },
		className: cn(base, sizes[size], variants[variant], className),
		children: [
			showHeart && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
				className: "relative z-[1] h-4 w-4 fill-current",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "relative z-[1]",
				children
			}),
			showArrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
				className: "relative z-[1] h-4 w-4",
				"aria-hidden": "true"
			})
		]
	});
}
//#endregion
export { Button as t };
