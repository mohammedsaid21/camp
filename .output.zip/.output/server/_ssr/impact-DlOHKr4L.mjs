import { n as loadImpactProjects } from "./catalog-CnAAOriP.mjs";
import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/impact-DlOHKr4L.js
var $$splitComponentImporter = () => import("./impact-DDyo1xfI.mjs");
var Route = createFileRoute("/impact/")({
	loader: () => loadImpactProjects(),
	head: () => ({ meta: [
		{ title: "اصنع أثرًا | أثر" },
		{
			name: "description",
			content: "اختر مشروعًا وكن جزءًا من أثر حقيقي."
		},
		{
			property: "og:title",
			content: "اصنع أثرًا | أثر"
		},
		{
			property: "og:description",
			content: "اختر مشروعًا وكن جزءًا من أثر حقيقي."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
