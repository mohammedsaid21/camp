import { n as __toESM } from "../_runtime.mjs";
import { i as performance_default, n as motion, r as AnimatePresence, t as useInView } from "../_libs/framer-motion+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { a as Trigger2, i as Root2, n as Header, r as Item, t as Content2, v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { d as Droplets, i as Plus, l as Heart, m as ArrowLeft, n as Wheat, o as Minus, p as ChevronDown, r as Soup, u as Drumstick } from "../_libs/lucide-react.mjs";
import { t as Button } from "./Button-CnvJKd0u.mjs";
import { t as VaultClipPlayer } from "./VaultClipPlayer-C0tNB7aV.mjs";
import { f as HERO_IMAGE, g as originWhatsapp, h as STATS_NOTE, i as DONATE_ORIGINS, m as STATS, n as BRAND_FLOW, o as DONOR_FAQS, s as FIELD_REPORTS, t as ABOUT, u as GIVE_PACKS } from "./data-ZV2hr-of.mjs";
import { i as viewport, n as imageReveal, r as stagger, t as fadeUp } from "./motion-eVtbxBLw.mjs";
import { n as VerseBand, t as PathSteps } from "./PathSteps-BJQALBky.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, s as DonateButton, t as Dialog } from "./DonateChoice-QCG4rJNl.mjs";
import { n as Navbar, t as Footer } from "./Footer-D81NFqpf.mjs";
import { t as StickyMobileCTA } from "./StickyMobileCTA-EhvZX0mK.mjs";
import { t as Route } from "./routes-CxxD9Mdd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BbMQUdn5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "top",
		className: "relative overflow-hidden scroll-mt-24 pt-[5.5rem] pb-6 md:pt-28 md:pb-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-center gap-5 lg:grid-cols-2 lg:gap-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: "hidden",
					animate: "visible",
					variants: stagger(.1),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h1, {
							variants: fadeUp,
							className: "text-[clamp(1.85rem,8.5vw,3.6rem)] leading-[1.15] tracking-tight md:max-w-[14ch] md:leading-[1.1]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-light",
								children: "لكل تبرع أثر."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block font-bold",
								children: ["لكل أثر ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-accent",
									children: "دليل."
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
							variants: fadeUp,
							className: "mt-3 max-w-[42ch] text-sm leading-relaxed text-muted-foreground md:mt-4 md:text-base",
							children: "مَثَلُ الْمُؤْمِنِينَ فِي تَوَادِّهِمْ، وَتَرَاحُمِهِمْ، كَمَثَلِ الْجَسَدِ الْوَاحِدِ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							variants: fadeUp,
							className: "mt-4 flex flex-col gap-2.5 sm:mt-5 sm:flex-row sm:flex-wrap sm:gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								href: "#archive",
								className: "w-full sm:w-auto",
								children: "شوف التوثيق"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonateButton, {
								className: "w-full sm:w-auto",
								children: "تبرع الآن"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							variants: fadeUp,
							className: "mt-4 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground md:mt-6 md:text-sm",
							children: BRAND_FLOW.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [i > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-border",
									children: "→"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-foreground",
									children: step.label
								})]
							}, step.key))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: "hidden",
					animate: "visible",
					variants: imageReveal,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "group relative aspect-[16/9] overflow-hidden rounded-2xl border border-border sm:aspect-[16/10] lg:aspect-[5/4]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: HERO_IMAGE,
								alt: "توثيق ميداني لتجهيز مساعدات إنسانية",
								loading: "eager",
								className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-charcoal/40 via-transparent to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute bottom-3 start-3 rounded-full border border-border/70 bg-background/92 px-3 py-1 text-xs font-medium backdrop-blur-sm",
								children: "مخيم نسائم الرحمة"
							})
						]
					})
				})]
			})
		})
	});
}
function useCountUp(target, run) {
	const [value, setValue] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!run) return;
		let raf = 0;
		const start = performance_default.now();
		const duration = 1400;
		const tick = (now) => {
			const progress = Math.min(1, (now - start) / duration);
			setValue(Math.round(target * (1 - Math.pow(1 - progress, 3))));
			if (progress < 1) raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [target, run]);
	return value;
}
function StatItem({ value, prefix, label }) {
	const ref = (0, import_react.useRef)(null);
	const count = useCountUp(value, useInView(ref, {
		once: true,
		amount: .4
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		ref,
		variants: fadeUp,
		className: "py-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "font-display text-[clamp(1.8rem,4vw,2.6rem)] leading-none tracking-tight text-accent",
			children: [prefix, count.toLocaleString("en-US")]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1.5 text-xs text-muted-foreground md:text-sm",
			children: label
		})]
	});
}
function ImpactStats() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "impact",
		className: "scroll-mt-24 border-y border-border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: "hidden",
			whileInView: "visible",
			viewport,
			variants: stagger(.06),
			className: "mx-auto grid max-w-7xl grid-cols-2 px-5 md:grid-cols-3 md:px-10",
			children: STATS.map((stat, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("px-2 md:px-4", index % 2 === 1 && "border-s border-border", index >= 2 && "border-t border-border md:border-t-0", index > 0 && "md:border-s"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatItem, { ...stat })
			}, stat.label))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto max-w-7xl px-5 pb-4 text-xs text-muted-foreground md:px-10",
			children: STATS_NOTE
		})]
	});
}
function DonatePath() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "path",
		className: "scroll-mt-24 bg-background py-10 md:py-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: "hidden",
					whileInView: "visible",
					viewport,
					variants: fadeUp,
					className: "mb-5 max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: "قصة التبرع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-2xl font-semibold md:text-[1.75rem]",
							children: "من غزة أو برا غزة — نفس الأثر."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "التبرع بيوصل للمخيم من المكانين. بتختار الرقم حسب مكانك، وبعدها نفس الشغل."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: "hidden",
					whileInView: "visible",
					viewport,
					variants: fadeUp,
					className: "rounded-3xl bg-forest p-2 text-forest-foreground md:p-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 pb-4 pt-5 md:px-6 md:pt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-leaf",
							children: "وين بدك تتواصل من؟"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 max-w-[42ch] text-sm leading-relaxed text-white/70",
							children: "نفس التنفيذ بالمخيم. الفرق بس برقم الواتساب."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-px overflow-hidden rounded-[1.25rem] bg-white/15 sm:grid-cols-2",
						children: DONATE_ORIGINS.map((origin) => {
							const isOutside = origin.id === "outside";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.a, {
								href: originWhatsapp(origin.id),
								target: "_blank",
								rel: "noopener noreferrer",
								whileHover: { y: -1 },
								whileTap: { scale: .99 },
								className: cn("btn-shine flex min-h-[5.5rem] flex-col justify-center px-5 py-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50 focus-visible:ring-offset-2 focus-visible:ring-offset-forest", isOutside ? "btn-donate bg-accent text-accent-foreground" : "bg-white/10 text-white hover:bg-white/20"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("text-[11px] font-medium", isOutside ? "text-accent-foreground/75" : "text-white/55"),
										children: origin.kicker
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-1 flex items-center gap-2 text-base font-semibold",
										children: [
											isOutside && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
												className: "h-4 w-4 fill-current",
												"aria-hidden": "true"
											}),
											origin.label,
											!isOutside && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
												className: "h-4 w-4",
												"aria-hidden": "true"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: cn("mt-0.5 text-xs", isOutside ? "text-accent-foreground/80" : "text-white/70"),
										children: ["واتساب ", origin.code]
									})
								]
							}, origin.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: "hidden",
					whileInView: "visible",
					viewport,
					variants: fadeUp,
					className: "mt-4 rounded-3xl bg-ivory px-5 py-6 md:px-8 md:py-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "بعد الرسالة، نفس المسار."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PathSteps, { className: "mt-5" })]
				})
			]
		})
	});
}
var GiveMeterContext = (0, import_react.createContext)(null);
function useGiveMeter() {
	const ctx = (0, import_react.useContext)(GiveMeterContext);
	if (!ctx) throw new Error("useGiveMeter must be used inside GiveMeterProvider");
	return ctx;
}
function GiveMeterProvider({ children }) {
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const openMeter = (0, import_react.useCallback)((id) => setActiveId(id), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GiveMeterContext.Provider, {
		value: { openMeter },
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiveMeterDialog, {
			activeId,
			onOpenChange: (open) => !open && setActiveId(null)
		})]
	});
}
function packById(id) {
	const pack = GIVE_PACKS.find((item) => item.id === id);
	if (!pack) throw new Error(`Unknown give pack: ${id}`);
	return pack;
}
function unitLabel(unit, plural, qty) {
	return qty === 1 ? unit : plural;
}
function kindIcon(id) {
	if (id === "chicken") return Drumstick;
	if (id === "meal") return Soup;
	if (id === "water") return Droplets;
	return Wheat;
}
function GiveMeterDialog({ activeId, onOpenChange }) {
	const pack = activeId ? packById(activeId) : GIVE_PACKS[0];
	const [qty, setQty] = (0, import_react.useState)(pack.defaultQty);
	const [kindId, setKindId] = (0, import_react.useState)(pack.kinds[0].id);
	(0, import_react.useEffect)(() => {
		if (!activeId) return;
		const next = packById(activeId);
		setQty(next.defaultQty);
		setKindId(next.kinds[0].id);
	}, [activeId]);
	const kind = pack.kinds.find((item) => item.id === kindId) ?? pack.kinds[0];
	const perUsd = kind.perUsd;
	const total = qty * perUsd;
	const showKinds = pack.kinds.length > 1;
	const Icon = kindIcon(kind.id);
	const percent = (qty - pack.min) / (pack.max - pack.min) * 100;
	const units = unitLabel(pack.unit, pack.unitPlural, qty);
	const hint = `كل ${pack.unit} = ${perUsd} دولار. ${pack.defaultQty} ${unitLabel(pack.unit, pack.unitPlural, pack.defaultQty)} = ${pack.defaultQty * perUsd}$.`;
	const sentence = (0, import_react.useMemo)(() => `${pack.action} ${qty} ${units} — ${kind.label} مقابل ${total}$`, [
		pack.action,
		qty,
		units,
		kind.label,
		total
	]);
	const nudge = (dir) => {
		setQty((current) => Math.min(pack.max, Math.max(pack.min, current + dir * pack.step)));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: activeId !== null,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[min(92dvh,760px)] w-[calc(100%-1.25rem)] max-w-md gap-3 overflow-y-auto rounded-3xl border-border p-4 sm:gap-4 sm:rounded-3xl sm:p-8 [&>button]:start-4 [&>button]:end-auto [&>button]:right-auto [&>button]:left-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "space-y-1 pe-8 text-start sm:text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: pack.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "flex items-center gap-2 text-xl sm:text-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-9 w-9 items-center justify-center rounded-full bg-ivory text-primary sm:h-10 sm:w-10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "h-5 w-5",
									"aria-hidden": "true"
								})
							}), pack.title]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: hint })
					]
				}),
				showKinds && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium",
					children: "شو بدك تبعت؟"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: pack.kinds.map((item) => {
						const selected = item.id === kind.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setKindId(item.id),
							className: `rounded-2xl border px-2 py-2.5 text-center transition-colors ${selected ? "border-primary bg-ivory text-foreground" : "border-border bg-card text-muted-foreground hover:border-primary/40"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-semibold",
									children: item.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 block text-[11px]",
									children: item.desc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `mt-1 block text-xs font-bold ${selected ? "text-accent" : ""}`,
									children: [item.perUsd, "$"]
								})
							]
						}, item.id);
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl bg-forest px-4 py-5 text-center text-forest-foreground sm:px-5 sm:py-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-white/70",
							children: [
								pack.action,
								" · ",
								kind.label
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
							mode: "wait",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
								initial: {
									opacity: 0,
									y: 8
								},
								animate: {
									opacity: 1,
									y: 0
								},
								exit: {
									opacity: 0,
									y: -8
								},
								transition: { duration: .18 },
								className: "mt-1 font-display text-[clamp(2.2rem,8vw,3.4rem)] leading-none tracking-tight",
								children: qty
							}, `${kind.id}-${qty}`)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-white/70",
							children: units
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-white/50",
							children: "المبلغ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-4xl text-accent",
							children: ["$", total]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "أقل",
							onClick: () => nudge(-1),
							className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-border bg-card text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-4 w-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							dir: "ltr",
							type: "range",
							min: pack.min,
							max: pack.max,
							step: pack.step,
							value: qty,
							onChange: (e) => setQty(Number(e.target.value)),
							className: "give-slider h-2 w-full cursor-pointer appearance-none rounded-full",
							style: { background: `linear-gradient(to right, #1b7a4a ${percent}%, #d8eadc ${percent}%)` },
							"aria-valuemin": pack.min,
							"aria-valuemax": pack.max,
							"aria-valuenow": qty,
							"aria-label": pack.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "أكثر",
							onClick: () => nudge(1),
							className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-border bg-card text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: pack.presets.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setQty(preset),
						className: `rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${qty === preset ? "bg-primary text-primary-foreground" : "bg-ivory text-foreground hover:bg-surface-2"}`,
						children: [
							preset,
							" ",
							unitLabel(pack.unit, pack.unitPlural, preset)
						]
					}, preset))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-sm font-medium text-foreground",
					children: sentence
				}),
				pack.estimate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-ivory px-3 py-3 text-start text-xs leading-relaxed text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold text-foreground",
							children: "تفاصيل التكلفة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1",
							children: pack.estimate
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1",
							children: [
								"يشمل: ",
								pack.includes.join("، "),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["ما يشمل: ", pack.excludes.join("، ")] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-xs text-muted-foreground",
					children: "وين بدك تتواصل من؟"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						href: originWhatsapp("outside", `السلام عليكم، حابب أتبرع عبر أثر لمخيم نسائم الرحمة:\n${sentence}`),
						variant: "donate",
						className: "w-full",
						onClick: () => onOpenChange(false),
						children: "برا غزة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						href: originWhatsapp("gaza", `السلام عليكم، حابب أتبرع عبر أثر لمخيم نسائم الرحمة:\n${sentence}`),
						variant: "primary",
						className: "w-full",
						onClick: () => onOpenChange(false),
						children: "من غزة"
					})]
				})
			]
		})
	});
}
function ReportFacts({ report }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const rows = [
		{
			k: "الموقع",
			v: report.place
		},
		{
			k: "تاريخ التنفيذ",
			v: report.date ?? "يُضاف من سجل التنفيذ"
		},
		{
			k: "المستفيدون",
			v: `${report.figure} ${report.figureLabel}`
		},
		{
			k: "الكمية",
			v: report.quantity ?? "يُضاف من سجل التنفيذ"
		},
		{
			k: "تكلفة المشروع",
			v: report.cost ?? "يُضاف من سجل التنفيذ"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mt-3 space-y-1.5 text-sm",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between gap-3 border-b border-border/70 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-muted-foreground",
					children: row.k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "text-end font-medium",
					children: row.v
				})]
			}, row.k))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted-foreground",
			children: report.scope
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setOpen((v) => !v),
			className: "mt-2 text-sm font-medium text-primary",
			"aria-expanded": open,
			children: open ? "إخفاء السجل" : "عرض سجل المشروع"
		}),
		open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted-foreground",
			children: report.record
		})
	] });
}
function ReportMedia({ report, uploads }) {
	const clip = uploads.find((item) => item.projectId === report.id);
	if (clip) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultClipPlayer, {
		src: clip.videoUrl,
		poster: clip.posterUrl ?? report.image,
		title: report.title
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative aspect-[9/16] overflow-hidden bg-charcoal",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: report.image,
			alt: report.title,
			className: "h-full w-full object-cover"
		})
	});
}
function DocumentedCampaign({ uploads }) {
	const { openMeter } = useGiveMeter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "archive",
		className: "scroll-mt-24 bg-surface py-10 md:py-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: "hidden",
				whileInView: "visible",
				viewport,
				variants: fadeUp,
				className: "mb-8 flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-primary",
					children: "أرشيف التنفيذ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl font-semibold md:text-[1.75rem]",
					children: "كل رقم إله سجل."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex max-w-[36ch] flex-col items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "الأرقام من التنفيذ بالمخيم. اللي لسا ما انرفق بسجل الشراء، منتركه فارغ بدل ما نخترعه."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/videos",
						className: "text-sm font-medium text-primary",
						children: "كل الفيديوهات"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: "hidden",
				whileInView: "visible",
				viewport,
				variants: stagger(.08),
				className: "grid gap-6 md:grid-cols-3",
				children: [FIELD_REPORTS.map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
					id: report.id,
					variants: fadeUp,
					className: "flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-[0_12px_32px_#1435280f] scroll-mt-28",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportMedia, {
						report,
						uploads
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-1 flex-col p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-leaf",
								children: report.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 text-lg font-semibold",
								children: report.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: report.lead
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportFacts, { report }),
							report.id === "khubz" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => openMeter("khubz"),
								className: "btn-shine mt-4 rounded-full bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground",
								children: "كم عائلة بدك تطعم؟"
							})
						]
					})]
				}, report.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
					id: "maa",
					variants: fadeUp,
					className: "flex flex-col overflow-hidden rounded-2xl bg-forest p-4 text-forest-foreground shadow-[0_12px_32px_#0f3d2e33] scroll-mt-28",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-[9/16] overflow-hidden rounded-xl bg-white/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-forest/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, {
								className: "absolute bottom-4 start-4 h-10 w-10 text-white",
								"aria-hidden": "true"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs text-white/55",
							children: "فرصة عطاء · تقدير تكلفة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1.5 text-lg font-semibold",
							children: "شاحنة الماء"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-white/75",
							children: "200$ تكلفة تقديرية لتوفير الماء لـ100 شخص حسب تكلفة التنفيذ الحالية."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "mt-3 space-y-1.5 text-sm",
							children: [
								{
									k: "يشمل التقدير",
									v: "شراء الماء، النقل، التوزيع"
								},
								{
									k: "ما يشمل",
									v: "شراء شاحنة"
								},
								{
									k: "اللتر والأيام",
									v: "بتننشر مع كل تنفيذ"
								}
							].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-3 border-b border-white/15 py-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-white/55",
									children: row.k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "text-end",
									children: row.v
								})]
							}, row.k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-auto border-t border-white/15 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl text-accent",
								children: "100"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ms-2 text-xs text-white/55",
								children: "شخص ≈ 200$"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => openMeter("maa"),
							className: "btn-shine mt-3 rounded-full bg-accent px-4 py-2.5 text-sm font-semibold text-accent-foreground",
							children: "احسب التقدير"
						})
					]
				})]
			})]
		})
	});
}
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
function DonorFaq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "faq",
		className: "scroll-mt-24 bg-background py-10 md:py-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-5 md:px-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: "hidden",
				whileInView: "visible",
				viewport,
				variants: fadeUp,
				className: "mb-6 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-primary",
					children: "قبل ما تتبرّع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl font-semibold md:text-[1.75rem]",
					children: "سؤالين بيسألهن كل متبرّع"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: "hidden",
				whileInView: "visible",
				viewport,
				variants: fadeUp,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
					type: "single",
					collapsible: true,
					defaultValue: "proof",
					className: "flex flex-col gap-3",
					children: DONOR_FAQS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
						value: item.id,
						className: "overflow-hidden rounded-2xl border border-border border-b-0 bg-card px-4 shadow-[0_10px_24px_#1435280c] md:px-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
							className: "py-4 text-start text-base font-semibold hover:no-underline",
							children: item.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionContent, {
							className: "pb-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "leading-relaxed text-muted-foreground",
								children: item.a
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 grid gap-2 sm:grid-cols-3",
								children: item.notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-xl bg-ivory px-3 py-2.5 text-start",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-foreground",
										children: note.t
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 text-xs text-muted-foreground",
										children: note.d
									})]
								}, note.t))
							})]
						})]
					}, item.id))
				})
			})]
		})
	});
}
function SadaqaSection() {
	const { openMeter } = useGiveMeter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "donate",
		className: "scroll-mt-24 bg-forest py-12 text-forest-foreground md:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: "hidden",
			whileInView: "visible",
			viewport,
			variants: fadeUp,
			className: "mx-auto max-w-7xl px-5 text-center md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-leaf",
					children: "صدقة ما بتنتهي عند الإيد"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mx-auto mt-2 text-[clamp(1.7rem,4vw,2.5rem)] font-semibold leading-snug",
					children: "اللي بتعطيه اليوم، بتشوف أثره بكرة."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
					className: "font-verse mx-auto mt-5  text-lg leading-loose text-white/90 md:text-xl",
					children: "﴿مَن ذَا الَّذِي يُقْرِضُ اللَّهَ قَرْضًا حَسَنًا فَيُضَاعِفَهُ لَهُ أَضْعَافًا كَثِيرَةً﴾"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-white/55",
					children: "سورة البقرة — ٢٤٥"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-4 max-w-[42ch] text-sm text-white/75",
					children: "مو كلام تبرعات. شغل بالمخيم، متصوّر، وواصل. إذا حابب تكون جزء من الجاي — الباب مفتوح."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-8 grid max-w-2xl grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => openMeter("khubz"),
							className: "rounded-2xl border border-white/15 bg-white/10 px-2 py-3 backdrop-blur-sm transition-colors hover:bg-white/20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-semibold text-white",
								children: "أكل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-[11px] text-white/60",
								children: "خبز · جاجة · طبخة"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#iftar",
							className: "rounded-2xl border border-white/15 bg-white/10 px-2 py-3 backdrop-blur-sm transition-colors hover:bg-white/20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-semibold text-white",
								children: "إفطار"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-[11px] text-white/60",
								children: "على سفرة صائم"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => openMeter("maa"),
							className: "rounded-2xl border border-white/15 bg-white/10 px-2 py-3 backdrop-blur-sm transition-colors hover:bg-white/20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-semibold text-white",
								children: "ماء"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-[11px] text-white/60",
								children: "تقدير: 100 شخص ≈ 200$"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap justify-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "/impact",
							variant: "ghostOnDark",
							children: "اصنع أثرًا"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "/zakat",
							variant: "ghostOnDark",
							children: "احسب زكاتك"
						}),
						DONATE_ORIGINS.map((origin) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: originWhatsapp(origin.id),
							variant: origin.id === "outside" ? "donate" : "ghostOnDark",
							children: origin.label
						}, origin.id))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-white/55",
					children: "رقم للي برا غزة، ورقم لأهل غزة."
				})
			]
		})
	});
}
function AboutSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "about",
		className: "scroll-mt-24 bg-ivory py-12 md:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: "hidden",
					whileInView: "visible",
					viewport,
					variants: fadeUp,
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: ABOUT.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-[clamp(1.7rem,4vw,2.4rem)] font-semibold leading-snug",
							children: ABOUT.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 space-y-3 text-sm leading-relaxed text-muted-foreground md:text-base",
							children: ABOUT.paragraphs.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: p }, p))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: "hidden",
					whileInView: "visible",
					viewport,
					variants: stagger(.06),
					className: "mt-8 grid gap-3 sm:grid-cols-2",
					children: ABOUT.blocks.map((block) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
						variants: fadeUp,
						className: "rounded-2xl border border-border bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: block.h
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground",
							children: block.d
						})]
					}, block.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: "hidden",
					whileInView: "visible",
					viewport,
					variants: fadeUp,
					className: "mt-8 flex flex-wrap items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "w-full text-sm text-muted-foreground",
						children: "للتبرع والاستفسار، تواصل معنا عبر واتساب حسب مكانك:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: DONATE_ORIGINS.map((origin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							href: originWhatsapp(origin.id),
							variant: origin.id === "outside" ? "donate" : "primary",
							size: "sm",
							children: [
								origin.label,
								" (",
								origin.code,
								")"
							]
						}, origin.id))
					})]
				})
			]
		})
	});
}
function Index() {
	const uploads = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiveMeterProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseBand, {
					ayah: "﴿مَّثَلُ الَّذِينَ يُنفِقُونَ أَمْوَالَهُمْ فِي سَبِيلِ اللَّهِ كَمَثَلِ حَبَّةٍ أَنبَتَتْ سَبْعَ سَنَابِلَ فِي كُلِّ سُنبُلَةٍ مِّائَةُ حَبَّةٍ﴾",
					surah: "سورة البقرة — ٢٦١"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImpactStats, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonatePath, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentedCampaign, { uploads }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonorFaq, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseBand, {
					ayah: "﴿لَن تَنَالُوا الْبِرَّ حَتَّىٰ تُنفِقُوا مِمَّا تُحِبُّونَ﴾",
					surah: "سورة آل عمران — ٩٢"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SadaqaSection, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutSection, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyMobileCTA, {})
		]
	}) });
}
//#endregion
export { Index as component };
