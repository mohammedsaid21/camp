import { n as __toESM } from "../_runtime.mjs";
import { n as motion } from "../_libs/framer-motion+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as Play } from "../_libs/lucide-react.mjs";
import { c as videoProjectLabel, i as VIDEO_PROJECTS, o as fieldVideoProjectId } from "./projects-D6nJ4DmA.mjs";
import { t as VaultClipPlayer } from "./VaultClipPlayer-C0tNB7aV.mjs";
import { c as FIELD_VIDEOS } from "./data-ZV2hr-of.mjs";
import { i as viewport, r as stagger, t as fadeUp } from "./motion-eVtbxBLw.mjs";
import { n as Navbar, t as Footer } from "./Footer-D81NFqpf.mjs";
import { t as StickyMobileCTA } from "./StickyMobileCTA-EhvZX0mK.mjs";
import { t as Route } from "./videos-DiNHcc4b.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/videos-Cb667l1M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FieldClip({ src, poster, title, className }) {
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (failed || !playing) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => {
			if (!failed) setPlaying(true);
		},
		className: cn("relative block aspect-[9/16] w-full overflow-hidden bg-charcoal", className),
		"aria-label": failed ? title : `تشغيل فيديو ${title}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: poster,
				alt: title,
				className: "h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-charcoal/25" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0 flex items-center justify-center",
				children: !failed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-14 w-14 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-[0_10px_24px_#f26b214d]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
						className: "ms-0.5 h-6 w-6 fill-current",
						"aria-hidden": "true"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-3 start-3 rounded-full border border-white/25 bg-background/92 px-2.5 py-1 text-[11px] font-medium backdrop-blur-sm",
				children: failed ? "التوثيق بالصورة" : "مشاهدة الفيديو"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative aspect-[9/16] overflow-hidden bg-black", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			className: "field-clip-video h-full w-full object-contain",
			controls: true,
			playsInline: true,
			autoPlay: true,
			preload: "metadata",
			poster,
			onError: () => {
				setFailed(true);
				setPlaying(false);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
				src,
				type: "video/mp4"
			})
		})
	});
}
function VideosArchive({ uploads }) {
	const items = [...FIELD_VIDEOS.map((clip) => ({
		key: clip.id,
		title: clip.title,
		place: clip.place,
		video: clip.video,
		poster: clip.image,
		projectId: fieldVideoProjectId(clip.id),
		kind: "field"
	})), ...uploads.map((clip) => ({
		key: clip.id,
		title: clip.title,
		place: "مخيم نسائم الرحمة",
		video: clip.videoUrl,
		poster: clip.posterUrl,
		projectId: clip.projectId,
		kind: "upload"
	}))];
	const groups = VIDEO_PROJECTS.map((project) => ({
		...project,
		clips: items.filter((item) => item.projectId === project.id)
	})).filter((group) => group.clips.length > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-surface pt-28 pb-12 md:pb-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: "hidden",
				whileInView: "visible",
				viewport,
				variants: fadeUp,
				className: "mb-8 max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-primary",
						children: "أرشيف الفيديو"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-[clamp(1.7rem,4vw,2.4rem)] font-semibold leading-snug",
						children: "كل التصوير من المخيم، بمكان واحد."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted-foreground md:text-base",
						children: [items.length, " فيديوهات من التنفيذ بالميدان. اضغط عالفيديو لحتى يشتغل؛ ما بتنزل إلا لما تطلبها، عشان الصفحة تضل خفيفة."]
					})
				]
			}), groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-xl font-semibold",
					children: group.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.ul, {
					initial: "hidden",
					whileInView: "visible",
					viewport,
					variants: stagger(.08),
					className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
					children: group.clips.map((clip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.li, {
						variants: fadeUp,
						className: "overflow-hidden rounded-2xl border border-border bg-card shadow-[0_12px_32px_#1435280f]",
						children: [clip.kind === "field" && clip.poster ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldClip, {
							src: clip.video,
							poster: clip.poster,
							title: clip.title
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultClipPlayer, {
							src: clip.video,
							poster: clip.poster,
							title: clip.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-primary",
									children: videoProjectLabel(clip.projectId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 text-lg font-semibold",
									children: clip.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: clip.place
								})
							]
						})]
					}, clip.key))
				})]
			}, group.id))]
		})
	});
}
function VideosPage() {
	const uploads = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideosArchive, { uploads }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyMobileCTA, {})
		]
	});
}
//#endregion
export { VideosPage as component };
