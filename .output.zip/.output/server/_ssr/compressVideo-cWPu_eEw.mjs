import { t as FFmpeg } from "../_libs/ffmpeg__ffmpeg.mjs";
import { n as toBlobURL, t as fetchFile } from "../_libs/ffmpeg__util.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/compressVideo-cWPu_eEw.js
var CORE_BASE = "https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/esm";
var ffmpeg = null;
var loading = null;
async function getFfmpeg() {
	if (ffmpeg?.loaded) return ffmpeg;
	if (loading) return loading;
	loading = (async () => {
		const instance = new FFmpeg();
		await instance.load({
			coreURL: await toBlobURL(`${CORE_BASE}/ffmpeg-core.js`, "text/javascript"),
			wasmURL: await toBlobURL(`${CORE_BASE}/ffmpeg-core.wasm`, "application/wasm")
		});
		ffmpeg = instance;
		return instance;
	})();
	try {
		return await loading;
	} finally {
		loading = null;
	}
}
var COMPRESS_ARGS = [
	"-vf",
	"scale=-2:720",
	"-c:v",
	"libx264",
	"-crf",
	"30",
	"-preset",
	"veryfast",
	"-movflags",
	"+faststart",
	"-c:a",
	"aac",
	"-b:a",
	"64k"
];
async function compressVaultVideo(file, onProgress) {
	onProgress(.02);
	const runtime = await getFfmpeg();
	onProgress(.08);
	const inputName = "input.bin";
	const outputName = "output.mp4";
	await runtime.writeFile(inputName, await fetchFile(file));
	const onProg = ({ progress }) => {
		onProgress(Math.min(.08 + Math.max(progress, 0) * .9, .98));
	};
	runtime.on("progress", onProg);
	try {
		let code = await runtime.exec([
			"-i",
			inputName,
			...COMPRESS_ARGS,
			outputName
		]);
		if (code !== 0) code = await runtime.exec([
			"-i",
			inputName,
			"-vf",
			"scale=-2:720",
			"-c:v",
			"libx264",
			"-crf",
			"30",
			"-preset",
			"veryfast",
			"-movflags",
			"+faststart",
			"-an",
			outputName
		]);
		if (code !== 0) throw new Error("فشل ضغط الفيديو.");
		const output = await runtime.readFile(outputName);
		const bytes = output instanceof Uint8Array ? new Uint8Array(output) : /* @__PURE__ */ new Uint8Array();
		if (bytes.byteLength === 0) throw new Error("فشل ضغط الفيديو.");
		onProgress(1);
		return new File([bytes], `${file.name.replace(/\.[^.]+$/, "")}.mp4`, { type: "video/mp4" });
	} finally {
		runtime.off("progress", onProg);
		await runtime.deleteFile(inputName).catch(() => void 0);
		await runtime.deleteFile(outputName).catch(() => void 0);
	}
}
//#endregion
export { compressVaultVideo };
