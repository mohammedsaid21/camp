import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Money-BeB2rs0p.js
var import_jsx_runtime = require_jsx_runtime();
function formatUsd(amount) {
	return `$${amount.toLocaleString("en-US")}`;
}
function parseContributeAmount(raw) {
	if (!raw) return null;
	const amount = Number(raw);
	if (!Number.isFinite(amount) || amount <= 0) return null;
	return amount;
}
function contributeMessage(title, amount) {
	if (amount !== null) return `السلام عليكم، حابب أساهم بـ $${amount} في مشروع «${title}» عبر أثر لمخيم نسائم الرحمة.`;
	return `السلام عليكم، حابب أساهم في مشروع «${title}» عبر أثر لمخيم نسائم الرحمة.`;
}
function Money({ amount, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		dir: "ltr",
		className: cn("inline-block", className),
		children: formatUsd(amount)
	});
}
//#endregion
export { contributeMessage as n, parseContributeAmount as r, Money as t };
