import { n as __toESM } from "../_runtime.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as Lock } from "../_libs/lucide-react.mjs";
import { D as isRedirect, _ as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as videoProjectLabel, i as VIDEO_PROJECTS, n as VAULT_MIME_TYPES, r as VAULT_SOURCE_MAX_BYTES, t as VAULT_MAX_BYTES } from "./projects-D6nJ4DmA.mjs";
import { a as lockVault, c as updateVaultVideoProject, n as finalizeVaultUpload, o as prepareVaultUpload, s as unlockVault, t as deleteVaultVideo } from "./vault.functions-FDUu2vKl.mjs";
import { t as Route } from "./ayla-B5fY0ZPr.mjs";
import { t as VaultClipPlayer } from "./VaultClipPlayer-C0tNB7aV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ayla-DuhcaWIX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
function formatBytes(bytes) {
	if (bytes < 1024) return `${bytes} بايت`;
	if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
function uploadWithProgress(url, file, contentType, onProgress) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open("PUT", url);
		xhr.setRequestHeader("Content-Type", contentType);
		xhr.upload.onprogress = (event) => {
			if (!event.lengthComputable) return;
			onProgress(event.loaded / event.total, event.loaded, event.total);
		};
		xhr.onload = () => {
			if (xhr.status >= 200 && xhr.status < 300) resolve();
			else reject(/* @__PURE__ */ new Error("فشل رفع الملف إلى التخزين."));
		};
		xhr.onerror = () => reject(/* @__PURE__ */ new Error("فشل رفع الملف إلى التخزين."));
		xhr.send(file);
	});
}
function errorMessage(error) {
	return error instanceof Error ? error.message : "صار خطأ. جرب مرة ثانية.";
}
function VaultPage({ initial }) {
	const unlock = useServerFn(unlockVault);
	const lock = useServerFn(lockVault);
	const prepare = useServerFn(prepareVaultUpload);
	const finalize = useServerFn(finalizeVaultUpload);
	const remove = useServerFn(deleteVaultVideo);
	const updateProject = useServerFn(updateVaultVideoProject);
	const [unlocked, setUnlocked] = (0, import_react.useState)(initial.unlocked);
	const [videos, setVideos] = (0, import_react.useState)(initial.videos);
	const [password, setPassword] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [fileKey, setFileKey] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [loadedBytes, setLoadedBytes] = (0, import_react.useState)(0);
	const [totalBytes, setTotalBytes] = (0, import_react.useState)(0);
	const [originalBytes, setOriginalBytes] = (0, import_react.useState)(null);
	const [compressedBytes, setCompressedBytes] = (0, import_react.useState)(null);
	function resetProgress() {
		setPhase("idle");
		setProgress(0);
		setLoadedBytes(0);
		setTotalBytes(0);
		setOriginalBytes(null);
		setCompressedBytes(null);
	}
	async function onUnlock(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			const result = await unlock({ data: { password } });
			setUnlocked(true);
			setVideos(result.videos);
			setPassword("");
		} catch (caught) {
			setError(errorMessage(caught));
		} finally {
			setBusy(false);
		}
	}
	async function onLock() {
		await lock();
		setUnlocked(false);
		setVideos([]);
	}
	async function onUpload(event) {
		event.preventDefault();
		if (!file) {
			setError("اختَر فيديو أول.");
			return;
		}
		if (!projectId) {
			setError("حدد نوع المشروع حتى ينعرض بالمكان الصحيح.");
			return;
		}
		setBusy(true);
		setError(null);
		setOriginalBytes(file.size);
		setCompressedBytes(null);
		try {
			setPhase("loading");
			setProgress(4);
			const { compressVaultVideo } = await import("./compressVideo-cWPu_eEw.mjs");
			const compressed = await compressVaultVideo(file, (ratio) => {
				setPhase(ratio < .09 ? "loading" : "compressing");
				setProgress(Math.round(ratio * 100));
			});
			if (compressed.size > 52428800) throw new Error(`بعد الضغط صار ${formatBytes(compressed.size)}، وهذا أكبر من حد التخزين ${formatBytes(VAULT_MAX_BYTES)}.`);
			setCompressedBytes(compressed.size);
			setPhase("uploading");
			setProgress(0);
			setLoadedBytes(0);
			setTotalBytes(compressed.size);
			const prepared = await prepare({ data: {
				title: title.trim() || file.name.replace(/\.[^.]+$/, ""),
				fileName: compressed.name,
				contentType: "video/mp4",
				sizeBytes: compressed.size
			} });
			await uploadWithProgress(prepared.signedUrl, compressed, prepared.contentType, (ratio, loaded, total) => {
				setProgress(Math.round(ratio * 100));
				setLoadedBytes(loaded);
				setTotalBytes(total);
			});
			setPhase("saving");
			setProgress(100);
			const clip = await finalize({ data: {
				path: prepared.path,
				title: prepared.title,
				contentType: prepared.contentType,
				sizeBytes: prepared.sizeBytes,
				projectId
			} });
			setVideos((current) => [clip, ...current]);
			setTitle("");
			setProjectId("");
			setFile(null);
			setFileKey((key) => key + 1);
			resetProgress();
		} catch (caught) {
			setError(errorMessage(caught));
			setPhase("idle");
		} finally {
			setBusy(false);
		}
	}
	async function onDelete(id) {
		if (!window.confirm("تحذف هالفيديو؟")) return;
		setBusy(true);
		setError(null);
		try {
			await remove({ data: { id } });
			setVideos((current) => current.filter((clip) => clip.id !== id));
		} catch (caught) {
			setError(errorMessage(caught));
		} finally {
			setBusy(false);
		}
	}
	const phaseLabel = phase === "loading" ? "تحميل أداة الضغط…" : phase === "compressing" ? "ضغط الفيديو" : phase === "uploading" ? "رفع الملف" : phase === "saving" ? "حفظ السجل…" : null;
	if (!unlocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (event) => void onUnlock(event),
			className: "w-full max-w-sm rounded-3xl bg-card p-6 shadow-[0_8px_28px_#1435280c]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
					className: "mx-auto h-6 w-6 text-primary",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-center text-xl font-semibold",
					children: "صفحة خاصة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-sm text-muted-foreground",
					children: "أدخل كلمة السر عشان تشوف الأرشيف."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-5 block text-sm font-medium",
					htmlFor: "vault-password",
					children: "كلمة السر"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "vault-password",
					type: "password",
					autoComplete: "current-password",
					value: password,
					onChange: (event) => setPassword(event.target.value),
					className: "mt-2 h-11 w-full rounded-xl border border-input bg-transparent px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50"
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-destructive",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: busy,
					className: "mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground disabled:opacity-50",
					children: busy ? "جارٍ الفتح…" : "فتح الأرشيف"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-background pb-16 pt-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-primary",
						children: "أرشيف خاص"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold",
						children: "فيديوهاتك"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void onLock(),
						className: "min-h-11 rounded-full bg-ivory px-4 text-sm font-medium",
						children: "إغلاق"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => void onUpload(event),
					className: "mt-8 rounded-3xl bg-card p-5 shadow-[0_8px_28px_#1435280c]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "رفع فيديو"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								"قبل الرفع بنضغط الفيديو إلى 720p بنفس الوصفة الميدانية (crf 30). تقدر تختار ملف أصلي حتى",
								" ",
								formatBytes(VAULT_SOURCE_MAX_BYTES),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm font-medium",
							htmlFor: "vault-title",
							children: "العنوان"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "vault-title",
							value: title,
							onChange: (event) => setTitle(event.target.value),
							className: "mt-2 h-11 w-full rounded-xl border border-input bg-transparent px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm font-medium",
							htmlFor: "vault-project",
							children: "نوع المشروع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "vault-project",
							value: projectId,
							onChange: (event) => setProjectId(event.target.value),
							className: "mt-2 h-11 w-full rounded-xl border border-input bg-transparent px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50",
							required: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "اختر المشروع"
							}), VIDEO_PROJECTS.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: project.id,
								children: project.label
							}, project.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm font-medium",
							htmlFor: "vault-file",
							children: "الملف"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "vault-file",
							type: "file",
							accept: VAULT_MIME_TYPES.join(","),
							onChange: (event) => {
								const next = event.target.files?.[0] ?? null;
								if (next && next.size > 314572800) {
									setError(`الملف أكبر من ${formatBytes(VAULT_SOURCE_MAX_BYTES)}.`);
									setFile(null);
									return;
								}
								setFile(next);
								setError(null);
								resetProgress();
							},
							className: "mt-2 w-full text-sm file:me-3 file:rounded-full file:border-0 file:bg-ivory file:px-4 file:py-2"
						}, fileKey),
						file ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							dir: "ltr",
							children: [
								file.name,
								" · ",
								formatBytes(file.size)
							]
						}) : null,
						phase !== "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							"aria-live": "polite",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1.5 flex justify-between gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: phaseLabel }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										dir: "ltr",
										children: [progress, "%"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									role: "progressbar",
									"aria-valuemin": 0,
									"aria-valuemax": 100,
									"aria-valuenow": progress,
									"aria-label": phaseLabel ?? "التقدم",
									className: "h-2 overflow-hidden rounded-full bg-ivory",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full bg-primary transition-[width] duration-200",
										style: { width: `${progress}%` }
									})
								}),
								phase === "uploading" && totalBytes > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1.5 text-xs text-muted-foreground",
									dir: "ltr",
									children: [
										formatBytes(loadedBytes),
										" / ",
										formatBytes(totalBytes)
									]
								}) : null,
								compressedBytes !== null && originalBytes !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1.5 text-xs text-muted-foreground",
									children: [
										"الحجم بعد الضغط: ",
										formatBytes(compressedBytes),
										" (كان ",
										formatBytes(originalBytes),
										")"
									]
								}) : null
							]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-destructive",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: busy || !file || !projectId,
							className: "mt-4 inline-flex min-h-11 items-center justify-center rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground disabled:opacity-50",
							children: busy ? phaseLabel ?? "جارٍ العمل…" : "ضغط ورفع الفيديو"
						})
					]
				}),
				videos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-center text-sm text-muted-foreground",
					children: "ما في فيديوهات بعد. ارفع أول واحد من فوق."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
					children: videos.map((clip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "overflow-hidden rounded-2xl bg-card shadow-[0_12px_32px_#1435280f]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultClipPlayer, {
							src: clip.videoUrl,
							poster: clip.posterUrl,
							title: clip.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium text-primary",
										children: videoProjectLabel(clip.projectId)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-semibold",
										children: clip.title
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void onDelete(clip.id),
										className: "shrink-0 text-sm text-muted-foreground hover:text-destructive",
										children: "حذف"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs text-muted-foreground",
									htmlFor: `project-${clip.id}`,
									children: "مكان العرض"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: `project-${clip.id}`,
									value: clip.projectId,
									disabled: busy,
									onChange: (event) => {
										const next = event.target.value;
										updateProject({ data: {
											id: clip.id,
											projectId: next
										} }).then(() => {
											setVideos((current) => current.map((item) => item.id === clip.id ? {
												...item,
												projectId: next
											} : item));
										}).catch((caught) => setError(errorMessage(caught)));
									},
									className: "h-11 w-full rounded-xl border border-input bg-transparent px-3 text-sm",
									children: VIDEO_PROJECTS.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: project.id,
										children: project.label
									}, project.id))
								})
							]
						})]
					}, clip.id))
				})
			]
		})
	});
}
function AylaRoute() {
	const initial = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultPage, { initial });
}
//#endregion
export { AylaRoute as component };
