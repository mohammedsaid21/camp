import { n as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { l as Heart, t as X } from "../_libs/lucide-react.mjs";
import { t as Button } from "./Button-CnvJKd0u.mjs";
import { g as originWhatsapp, i as DONATE_ORIGINS, r as DONATE_MESSAGE } from "./data-ZV2hr-of.mjs";
import { a as DialogOverlay$1, c as DialogTrigger$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/DonateChoice-QCG4rJNl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogTrigger = DialogTrigger$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var DonateChoiceContext = (0, import_react.createContext)(null);
function useDonateChoice() {
	const ctx = (0, import_react.useContext)(DonateChoiceContext);
	if (!ctx) throw new Error("useDonateChoice must be used inside DonateChoiceProvider");
	return ctx;
}
function DonateChoiceProvider({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(DONATE_MESSAGE);
	const openDonate = (0, import_react.useCallback)((nextMessage) => {
		setMessage(nextMessage ?? "السلام عليكم، حابب أتبرع عبر أثر لمخيم نسائم الرحمة.");
		setOpen(true);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DonateChoiceContext.Provider, {
		value: { openDonate },
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-md gap-4 rounded-3xl border-border p-5 sm:p-6 [&>button]:start-4 [&>button]:end-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "space-y-1 pe-8 text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: "قصة التبرع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-xl sm:text-2xl",
							children: "وين بدك تتواصل من؟"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "نفس الشغل بالمخيم. الفرق بس برقم الواتساب، عشان الرسالة توصلك أسهل." })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: DONATE_ORIGINS.map((origin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						href: originWhatsapp(origin.id, message),
						variant: origin.id === "outside" ? "donate" : "primary",
						className: "w-full",
						onClick: () => setOpen(false),
						children: [origin.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium opacity-80",
							children: origin.code
						})]
					}, origin.id))
				})]
			})
		})]
	});
}
function DonateButton({ children = "تبرع الآن", className, size = "default", message }) {
	const { openDonate } = useDonateChoice();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => openDonate(message),
		className: cn("btn-shine btn-donate inline-flex min-h-11 items-center justify-center gap-2 bg-accent font-semibold text-accent-foreground shadow-[0_10px_24px_#f26b214d] transition-[transform,box-shadow,background] hover:bg-ember focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50 focus-visible:ring-offset-2 focus-visible:ring-offset-background", {
			default: "rounded-full px-7 py-3 text-sm",
			sm: "rounded-full px-5 py-2.5 text-sm"
		}[size], className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
			className: "relative z-[1] h-4 w-4 fill-current",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative z-[1]",
			children
		})]
	});
}
//#endregion
export { DialogTitle as a, DonateChoiceProvider as c, DialogHeader as i, DialogContent as n, DialogTrigger as o, DialogDescription as r, DonateButton as s, Dialog as t };
