import { n as motion } from "../_libs/framer-motion+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { a as DONATE_PATH } from "./data-ZV2hr-of.mjs";
import { i as viewport, r as stagger, t as fadeUp } from "./motion-eVtbxBLw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PathSteps-BJQALBky.js
var import_jsx_runtime = require_jsx_runtime();
function VerseBand({ ayah, surah, tone = "light" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: tone === "leaf" ? "bg-forest py-5 text-forest-foreground" : "border-y border-border bg-ivory py-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.figure, {
			initial: "hidden",
			whileInView: "visible",
			viewport,
			variants: fadeUp,
			className: "mx-auto max-w-4xl px-5 text-center md:px-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "font-verse text-lg leading-loose md:text-xl",
				children: ayah
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: `mt-1 text-xs ${tone === "leaf" ? "text-white/65" : "text-muted-foreground"}`,
				children: surah
			})]
		})
	});
}
function PathSteps({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.ol, {
		initial: "hidden",
		whileInView: "visible",
		viewport,
		variants: stagger(.05),
		className: cn("relative flex flex-col md:grid md:grid-cols-5 md:gap-x-2", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pointer-events-none absolute start-4 top-4 bottom-4 w-px bg-border md:hidden",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pointer-events-none absolute top-4 start-[10%] end-[10%] hidden h-px bg-border md:block",
				"aria-hidden": "true"
			}),
			DONATE_PATH.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.li, {
				variants: fadeUp,
				className: "relative flex gap-3 pb-5 last:pb-0 md:block md:pb-0 md:text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "relative z-[1] flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground md:mx-auto",
					children: Number(step.n)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 md:mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-semibold",
						children: step.t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm leading-relaxed text-muted-foreground",
						children: step.d
					})]
				})]
			}, step.n))
		]
	});
}
//#endregion
export { VerseBand as n, PathSteps as t };
