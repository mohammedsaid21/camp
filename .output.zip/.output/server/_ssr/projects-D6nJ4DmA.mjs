//#region node_modules/.nitro/vite/services/ssr/assets/projects-D6nJ4DmA.js
var VAULT_MAX_BYTES = 52428800;
var VAULT_SOURCE_MAX_BYTES = 314572800;
var VAULT_MIME_TYPES = [
	"video/mp4",
	"video/webm",
	"video/quicktime",
	"video/x-matroska"
];
var VIDEO_PROJECTS = [
	{
		id: "khubz",
		label: "توزيع الخبز"
	},
	{
		id: "iftar",
		label: "إفطار صائم"
	},
	{
		id: "helw",
		label: "توزيع الحلو"
	},
	{
		id: "bard",
		label: "توزيع البرد"
	},
	{
		id: "masjid",
		label: "مناشدة المسجد"
	},
	{
		id: "water",
		label: "المياه"
	},
	{
		id: "food",
		label: "إطعام عائلات"
	},
	{
		id: "other",
		label: "أخرى"
	}
];
var VIDEO_PROJECT_IDS = VIDEO_PROJECTS.map((item) => item.id);
function isVideoProjectId(value) {
	return VIDEO_PROJECTS.some((item) => item.id === value);
}
function videoProjectLabel(id) {
	return VIDEO_PROJECTS.find((item) => item.id === id)?.label ?? "أخرى";
}
function fieldVideoProjectId(id) {
	if (id.startsWith("khubz")) return "khubz";
	if (id === "iftar") return "iftar";
	if (id === "helw") return "helw";
	if (id === "bard") return "bard";
	if (id === "masjid") return "masjid";
	if (id === "maa" || id === "water") return "water";
	return "other";
}
//#endregion
export { VIDEO_PROJECT_IDS as a, videoProjectLabel as c, VIDEO_PROJECTS as i, VAULT_MIME_TYPES as n, fieldVideoProjectId as o, VAULT_SOURCE_MAX_BYTES as r, isVideoProjectId as s, VAULT_MAX_BYTES as t };
