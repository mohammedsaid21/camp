import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/thanks-DTCpPXCV.js
var $$splitComponentImporter = () => import("./thanks-jBRyuymI.mjs");
var Route = createFileRoute("/impact/$slug/thanks")({
	validateSearch: (search) => {
		const amount = search["amount"];
		if (typeof amount === "string" && amount.length > 0) return { amount };
		return {};
	},
	head: () => ({ meta: [{
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
