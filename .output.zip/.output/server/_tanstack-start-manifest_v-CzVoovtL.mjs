//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CzVoovtL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/__root.tsx",
		children: [
			"/",
			"/impact",
			"/ayla",
			"/videos",
			"/zakat"
		],
		preloads: [
			"/assets/index-B2iPt1ZH.js",
			"/assets/jsx-runtime-Cltr0gcK.js",
			"/assets/utils-BYDHo02_.js",
			"/assets/useStore-CmhnSiq1.js",
			"/assets/not-found-i5RsCZif.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B2iPt1ZH.js"
		} }]
	},
	"/": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BS7kqpTZ.js",
			"/assets/VaultClipPlayer-5xu1yr43.js",
			"/assets/Footer-jqTKEqIs.js",
			"/assets/motion-CuUA0Pmr.js",
			"/assets/PathSteps-CqMDhKmD.js",
			"/assets/dist-Bq9C1jpM.js",
			"/assets/StickyMobileCTA-CF7BvM-m.js"
		]
	},
	"/impact": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/impact/route.tsx",
		children: ["/impact/$slug", "/impact/"],
		preloads: [
			"/assets/route-CumR3m09.js",
			"/assets/Footer-jqTKEqIs.js",
			"/assets/StickyMobileCTA-CF7BvM-m.js"
		]
	},
	"/ayla": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/ayla.tsx",
		children: void 0,
		preloads: [
			"/assets/ayla-C5loukYM.js",
			"/assets/VaultClipPlayer-5xu1yr43.js",
			"/assets/projects-c98RZLEd.js"
		]
	},
	"/videos": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/videos.tsx",
		children: void 0,
		preloads: [
			"/assets/videos-AkdIsB4A.js",
			"/assets/VaultClipPlayer-5xu1yr43.js",
			"/assets/Footer-jqTKEqIs.js",
			"/assets/projects-c98RZLEd.js",
			"/assets/motion-CuUA0Pmr.js",
			"/assets/StickyMobileCTA-CF7BvM-m.js"
		]
	},
	"/zakat": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/zakat.tsx",
		children: void 0,
		preloads: [
			"/assets/zakat-B7J7Yyut.js",
			"/assets/Footer-jqTKEqIs.js",
			"/assets/dist-Bq9C1jpM.js"
		]
	},
	"/impact/$slug": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/impact/$slug/route.tsx",
		children: ["/impact/$slug/thanks", "/impact/$slug/"],
		preloads: ["/assets/route-BKvgxEZ-.js"]
	},
	"/impact/": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/impact/index.tsx",
		children: void 0,
		preloads: [
			"/assets/impact-D8t2GUlo.js",
			"/assets/FundingMeter-_gtFHyze.js",
			"/assets/motion-CuUA0Pmr.js",
			"/assets/PathSteps-CqMDhKmD.js"
		]
	},
	"/impact/$slug/thanks": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/impact/$slug/thanks.tsx",
		children: void 0,
		preloads: [
			"/assets/thanks-CZa8IM6U.js",
			"/assets/Money-CxhLdLDA.js",
			"/assets/motion-CuUA0Pmr.js"
		]
	},
	"/impact/$slug/": {
		filePath: "/home/kali/Desktop/works/visible-good-deeds-main/src/routes/impact/$slug/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-CpufaaoS.js",
			"/assets/FundingMeter-_gtFHyze.js",
			"/assets/Money-CxhLdLDA.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
