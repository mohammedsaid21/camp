import { n as __toESM } from "./_runtime.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "./_libs/@radix-ui/react-accordion+[...].mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { l as Heart } from "./_libs/lucide-react.mjs";
import { t as Button } from "./_ssr/Button-CnvJKd0u.mjs";
import { g as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./_ssr/route-DqACLSu3.mjs";
import { t as Money } from "./_ssr/Money-BeB2rs0p.mjs";
import { n as isFunded, t as FundingMeter } from "./_ssr/FundingMeter-Dc6aVB9d.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-CXXAKpzx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContributePanel({ project }) {
	const navigate = useNavigate();
	const [selected, setSelected] = (0, import_react.useState)(project.contributionPresets[0] ?? 10);
	const [custom, setCustom] = (0, import_react.useState)("");
	const amount = selected === "custom" ? Number(custom) : selected;
	const valid = Number.isFinite(amount) && amount > 0;
	const tier = (0, import_react.useMemo)(() => valid ? project.impactTiers.find((item) => item.amountUsd === amount) : void 0, [
		amount,
		project.impactTiers,
		valid
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-3xl bg-card p-5 shadow-[0_8px_28px_#1435280c] md:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "اختر مساهمتك"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [project.contributionPresets.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelected(preset),
					className: cn("min-h-11 rounded-full px-4 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50", selected === preset ? "bg-accent text-accent-foreground" : "bg-ivory text-foreground"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: preset })
				}, preset)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelected("custom"),
					className: cn("min-h-11 rounded-full px-4 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50", selected === "custom" ? "bg-accent text-accent-foreground" : "bg-ivory text-foreground"),
					children: "مبلغ آخر"
				})]
			}),
			selected === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "mt-3 h-11 w-full rounded-xl border border-input bg-transparent px-3 text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50",
				dir: "ltr",
				inputMode: "decimal",
				"aria-label": "مبلغ آخر",
				value: custom,
				onChange: (e) => setCustom(e.target.value.replace(/[^\d.]/g, ""))
			}),
			valid && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm leading-relaxed",
				children: [
					"ستساهم بـ ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						amount,
						className: "font-semibold"
					}),
					" في مشروع: ",
					project.title
				]
			}),
			tier ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: tier.what
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: !valid,
				onClick: () => {
					if (!valid) return;
					navigate({
						to: "/impact/$slug/thanks",
						params: { slug: project.slug },
						search: { amount: String(amount) }
					});
				},
				className: "btn-shine btn-donate mt-5 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-accent px-7 text-sm font-semibold text-accent-foreground transition-[transform,background] hover:bg-ember focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-leaf/50 disabled:opacity-50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						className: "h-4 w-4 fill-current",
						"aria-hidden": "true"
					}),
					"أريد أن أساهم بـ ",
					valid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount }) : "…"
				]
			})
		]
	});
}
function ProjectDetail({ project }) {
	const funded = isFunded(project.amountRaised, project.targetAmount, project.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "bg-background pb-20 pt-24 md:pt-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-5 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-primary",
					children: project.kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-[clamp(1.8rem,5vw,3rem)] font-semibold leading-tight",
					children: project.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-[52ch] text-muted-foreground",
					children: project.summary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: project.place
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 overflow-hidden rounded-3xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: project.image,
						alt: project.imageAlt,
						className: "aspect-[16/9] w-full object-cover"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FundingMeter, {
					project,
					size: "detail"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_20rem]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-semibold",
								children: "عن المشروع"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 space-y-4 text-sm leading-relaxed",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-medium",
										children: "ما المشكلة؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 text-muted-foreground",
										children: project.problem
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-medium",
										children: "من المستفيد؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 text-muted-foreground",
										children: project.beneficiary
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-medium",
										children: "ماذا نريد أن نحقق؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 text-muted-foreground",
										children: project.goal
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-medium",
										children: "كيف تُستخدم المساهمة؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 text-muted-foreground",
										children: project.useOfFunds
									})] })
								]
							})] }),
							project.impactTiers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-semibold",
								children: "أثر تبرعك"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 grid gap-3 sm:grid-cols-2",
								children: project.impactTiers.map((tier) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-2xl bg-ivory p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl text-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { amount: tier.amountUsd })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm leading-relaxed text-muted-foreground",
										children: tier.what
									})]
								}, tier.amountUsd))
							})] }),
							project.updates.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-semibold",
								children: "رحلة الأثر"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-4 space-y-3",
								children: project.updates.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `mt-1.5 h-2 w-2 shrink-0 rounded-full ${item.done ? "bg-primary" : "bg-border"}`,
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: item.done ? "font-medium" : "text-muted-foreground",
										children: item.label
									}), item.at ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted-foreground",
										children: item.at
									}) : null] })]
								}, item.id))
							})] })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "order-first lg:order-none lg:sticky lg:top-28 lg:self-start",
						children: funded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-3xl bg-forest p-5 text-forest-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-semibold",
									children: "اكتمل هذا الأثر"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-white/75",
									children: project.donorCount !== null ? `بفضل مساهمات ${project.donorCount} متبرعًا، وصل المشروع إلى هدفه.` : "هالمشروع موثّق كمكتمل على الموقع. ما في عدّاد جمع منشور له."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									href: "/impact",
									variant: "ghostOnDark",
									className: "mt-5 w-full",
									arrow: false,
									children: "شاهد مشاريع أخرى"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContributePanel, { project })
					})]
				})
			]
		})
	});
}
function ImpactProjectPage() {
	const { project } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectDetail, { project });
}
//#endregion
export { ImpactProjectPage as component };
